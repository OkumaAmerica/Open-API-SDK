﻿Imports Okuma.CGDATAPI.Enumerations
Imports Okuma.CGDATAPI.DataAPI
Imports System.Text
Imports Okuma.CGCMDAPI

Public Class CDataApi_Samples

#Region "CUserManagement - Log In/Out Samples"
    ''' <summary>
    ''' Log current user out
    ''' </summary>
    ''' <remarks></remarks>
    Public Shared Sub LogOut()
        Dim enErrorCode As Okuma.CGDATAPI.Enumerations.UserApiErrorCodeEnum
        GotoHomeScreen()
        enErrorCode = m_objUserMgr.LogOut()
        m_objUserMgr.CheckUserErrorCode(enErrorCode)
    End Sub

    ''' <summary>
    ''' Log in with user id and password
    ''' </summary>
    ''' <remarks></remarks>
    Public Shared Sub LogIn(strUserId As String, strPassword As String)
        Dim enErrorCode As UserApiErrorCodeEnum
        GotoHomeScreen()

        enErrorCode = m_objUserMgr.LogIn(strUserId, strPassword)
        m_objUserMgr.CheckUserErrorCode(enErrorCode)
    End Sub

    ''' <summary>
    ''' Go to Home Screen
    ''' </summary>
    ''' <remarks>Log In/Out operation must be perforemd while NC is at Home Screen only</remarks>
    Public Shared Sub GotoHomeScreen()
        Dim objView As New Okuma.CGCMDAPI.CommandAPI.CViews
        objView.HomeScreen()
    End Sub

#End Region

End Class

