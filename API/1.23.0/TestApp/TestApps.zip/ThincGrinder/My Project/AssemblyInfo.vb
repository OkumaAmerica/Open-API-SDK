﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("ThincGrinderApp")> 
<Assembly: AssemblyDescription("THINC Grinder Sample application")> 
<Assembly: AssemblyCompany("Okuma America Corporation")> 
<Assembly: AssemblyProduct("ThincGrinderApp")> 
<Assembly: AssemblyCopyright("Copyright ©  2020 Okuma America Corporation")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("1399f851-6b07-410d-a3dd-213919ba6393")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.23.0.0")> 
<Assembly: AssemblyFileVersion("1.23.0.0")> 

'<Assembly: AssemblyVersion("1.0.0.0")> 
'compiled with
'OKUMA.CGDATAPI.DLL version 1.0.0.0
'OKUMA.CGCMDAPI.DLL version 1.0.0.0

'<Assembly: AssemblyVersion("1.20.0.0")> 
'For public release 1.20.0.0
'OKUMA.CGDATAPI.DLL version 1.1.0.0
'OKUMA.CGCMDAPI.DLL version 1.1.0.0
'Okuma.ApiLog2 verison 1.2.0.0
'Okuma.Api.LogService.Data version 1.0.0.0


'<Assembly: AssemblyVersion("1.21.1.0")> 
'For public release 1.21.1.0
'OKUMA.CGDATAPI.DLL version 1.1.0.0
'OKUMA.CGCMDAPI.DLL version 1.1.0.0
'Okuma.ApiLog2 verison 1.2.0.0
'Okuma.Api.LogService.Data version 1.0.0.0

'<Assembly: AssemblyVersion("1.21.6.0")> 
'For beta release 1.21.6.0
'OKUMA.CGDATAPI.DLL version 1.1.1.0
'OKUMA.CGCMDAPI.DLL version 1.1.0.0
'Okuma.ApiLog2 verison 1.2.0.0
'Okuma.Api.LogService.Data version 1.0.0.0

'<Assembly: AssemblyVersion("1.22.0.0")> 
'for public release 1.22.0.0

'<Assembly: AssemblyVersion("1.23.0.0")> 
'for public release 1.23.0.0