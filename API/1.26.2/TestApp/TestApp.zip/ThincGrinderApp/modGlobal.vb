﻿Imports System.Reflection
Imports System.Text
Imports Okuma.CGDATAPI
Imports Okuma.CGDATAPI.Enumerations
Imports Okuma.CGDATAPI.DataAPI
Imports Okuma.ApiLog2.CApiLog
Imports Okuma.Api.LogService.Data

Module modGlobal

    Public m_objMachine As Okuma.CGDATAPI.DataAPI.CMachine
    Public m_objAxis As Okuma.CGDATAPI.DataAPI.CAxis
    Public m_objSpindle As Okuma.CGDATAPI.DataAPI.CSpindle
    Public m_objProgram As Okuma.CGDATAPI.DataAPI.CProgram
    Public m_objWheel As Okuma.CGDATAPI.DataAPI.CWheel
    Public m_objTools As Okuma.CGDATAPI.DataAPI.CTools
    Public m_objWorkpiece As Okuma.CGDATAPI.DataAPI.CWorkpiece
    Public m_objSpec As Okuma.CGDATAPI.DataAPI.CSpec
    Public m_objIO As Okuma.CGDATAPI.DataAPI.CIO
    Public m_objVariables As Okuma.CGDATAPI.DataAPI.CVariables
    Public m_objOptionalParameter As Okuma.CGDATAPI.DataAPI.COptionalParameter

    Public m_objCmdProgram As Okuma.CGCMDAPI.CommandAPI.CProgram


    Public m_objOperationHistory As Okuma.CGDATAPI.DataAPI.MacMan.COperationHistory
    Public m_objMachiningReport As Okuma.CGDATAPI.DataAPI.MacMan.CMachiningReport
    Public m_objOperatingReport As Okuma.CGDATAPI.DataAPI.MacMan.COperatingReport
    Public m_objAlarmHistory As Okuma.CGDATAPI.DataAPI.MacMan.CAlarmHistory
    Public m_objOperatingHistory As Okuma.CGDATAPI.DataAPI.MacMan.COperatingHistory

    Public m_objIOAddress As CIOAddress

    Public m_objUserMgr As Okuma.CGDATAPI.DataAPI.CUserManagement



End Module

