﻿Imports Okuma.CMDATAPI.Enumerations
Imports Okuma.CMDATAPI.DataAPI
Imports Okuma.CMDATAPI.Structures
Imports System.Text
Imports Okuma.CMDATAPI

Public Class CDataApi_Samples

#Region "CUserManagement - Log In/Out Samples"
    ''' <summary>
    ''' Log current user out
    ''' </summary>
    ''' <remarks></remarks>
    Public Shared Sub LogOut()
        Dim enErrorCode As Enumerations.UserApiErrorCodeEnum
        GotoHomeScreen()
        enErrorCode = m_objUserMgr.LogOut()
        m_objUserMgr.CheckUserErrorCode(enErrorCode)
    End Sub

    ''' <summary>
    ''' Log in with user id and password
    ''' </summary>
    ''' <remarks></remarks>
    Public Shared Sub LogIn(strUserId As String, strPassword As String)
        Dim enErrorCode As UserApiErrorCodeEnum
        GotoHomeScreen()

        enErrorCode = m_objUserMgr.LogIn(strUserId, strPassword)
        m_objUserMgr.CheckUserErrorCode(enErrorCode)
    End Sub

    ''' <summary>
    ''' Go to Home Screen
    ''' </summary>
    ''' <remarks>Log In/Out operation must be perforemd while NC is at Home Screen only</remarks>
    Public Shared Sub GotoHomeScreen()
        Dim objView As New Okuma.CMCMDAPI.CommandAPI.CViews
        objView.HomeScreen()
    End Sub

#End Region

#Region "CPowers.EnergyUsage Samples"

    ''' <summary>
    ''' Get axis energy usage
    ''' </summary>
    ''' <remarks></remarks>
    Public Shared Function GetAxisEnergyUsage(ByVal enEnergyUsageAxisIndex As EnergyUsageAxisIndexEnum, energyUsageType As EnergyUsageTypeEnum) As Double
        Dim dblValue As Double

        dblValue = m_objPowers.GetAxisEnergyUsage(enEnergyUsageAxisIndex, energyUsageType)

        Return dblValue
    End Function

    ''' <summary>
    ''' Get all axis energy usage
    ''' </summary>
    ''' <remarks></remarks>
    Public Shared Sub GetAllAxisEnergyUsage(ByVal energyUsageType As EnergyUsageTypeEnum)
        Dim arEnergyUsageInfo As System.Array
        Dim sEnergyUsageInfo As EnergyUsageInfo
        Dim strValue As String

        arEnergyUsageInfo = m_objPowers.GetAxisEnergyUsageInfo()

        For Each sEnergyUsageInfo In arEnergyUsageInfo
            strValue = GetAxisEnergyUsage(sEnergyUsageInfo.AxisIndex, energyUsageType)
        Next
    End Sub

    ''' <summary>
    ''' Get total energy usage
    ''' </summary>
    ''' <remarks></remarks>
    Public Shared Function GetTotalEnergyUsage(ByVal enEnergyUsage As TotalEnergyUsageEnum, ByVal energyUsageType As EnergyUsageTypeEnum) As Double
        Dim dblValue As Double
        dblValue = m_objPowers.GetTotalEnergyUsage(enEnergyUsage, energyUsageType)

        Return dblValue
    End Function

    ''' <summary>
    ''' Get all total energy usage
    ''' </summary>
    ''' <remarks></remarks>
    Public Shared Sub GetAllTotalEnergyUsage(ByVal enEnergyUsageType As EnergyUsageTypeEnum)
        Dim strValue As String
        Dim enTotalEnergyUsages() As TotalEnergyUsageEnum
        Dim enTotalEnergyUsage As TotalEnergyUsageEnum

        enTotalEnergyUsages = System.Enum.GetValues(GetType(TotalEnergyUsageEnum))

        For Each enTotalEnergyUsage In enTotalEnergyUsages
            strValue = GetTotalEnergyUsage(enTotalEnergyUsage, enEnergyUsageType)
            strValue = String.Format("Index = {0}, Name = {1}, Value = {2}", enTotalEnergyUsage, enTotalEnergyUsage.ToString, strValue)
        Next

    End Sub

    ''' <summary>
    ''' Get start Date and Time of integral Energy Usage
    ''' </summary>
    ''' <remarks></remarks>
    Public Shared Function GetEnergyUsageDateTime() As String
        Dim strValue As String

        strValue = m_objPowers.GetEnergyUsageStartDateTime()

        Return strValue
    End Function

#End Region

End Class
