﻿Imports System.Reflection
Imports System.Text
Imports Okuma.CMDATAPI
Imports Okuma.CMCMDAPI
Imports Okuma.CMDATAPI.Enumerations
Imports Okuma.CMDATAPI.DataAPI
Imports Okuma.ApiLog2.CApiLog
Imports Okuma.Api.LogService.Data
Imports Okuma.CMDATAPI.Structures

Module modGlobal

    Public m_objMachine As CMachine
    Public m_objAtc As CATC
    Public m_objAxis As CAxis
    Public m_objAxis2 As CAxis
    Public m_objBS As CBallScrew
    Public m_objCoolant As CCoolant
    Public m_objCMOP As CMOPTool
    Public m_objProgram As CProgram
    Public m_objSpec As CSpec
    Public m_objSpindle As CSpindle
    Public m_objTools As CTools
    Public m_objVariables As CVariables
    Public m_objWorkPiece As CWorkpiece
    Public m_objAlarmHistory As MacMan.CAlarmHistory
    Public m_objOperatingReport As MacMan.COperatingReport
    Public m_objOperationHistory As MacMan.COperationHistory
    Public m_objOperatingHistory As MacMan.COperatingHistory
    Public m_objMachiningReport As MacMan.CMachiningReport '--------------

    Public m_objIO As Okuma.CMDATAPI.DataAPI.CIO
    Public m_objOptionalParameter As Okuma.CMDATAPI.DataAPI.COptionalParameter

    Public m_objToolID1 As Okuma.CMDATAPI.DataAPI.CTools2
    Public m_objToolID2 As Okuma.CMDATAPI.DataAPI.CTools2
    Public m_objUserMgr As Okuma.CMDATAPI.DataAPI.CUserManagement
    Public m_objPowers As Okuma.CMDATAPI.DataAPI.CPowers




End Module
