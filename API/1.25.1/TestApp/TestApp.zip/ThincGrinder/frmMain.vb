﻿Imports Okuma.CGDATAPI
Imports System.Reflection
Imports Okuma.CGDATAPI.Enumerations
Imports Okuma.CGDATAPI.DataApi
Imports System.Text
Imports Okuma.ApiLog2.CApiLog
Imports Okuma.Api.LogService.Data


Public Class frmMain
#Region "Private members"

#End Region

#Region "Form Events"

    Private Sub frmMain_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        ShutDown()
    End Sub

    Private Sub ShutDown()
        If m_objMachine IsNot Nothing Then

            m_objAxis = Nothing
            m_objSpindle = Nothing
            m_objProgram = Nothing
            m_objWheel = Nothing
            m_objTools = Nothing
            m_objWorkpiece = Nothing
            m_objSpec = Nothing
            m_objIO = Nothing
            m_objVariables = Nothing
            'm_objLoader = Nothing

            m_objCmdProgram = Nothing


            m_objOperationHistory = Nothing
            m_objMachiningReport = Nothing
            m_objOperatingReport = Nothing
            m_objAlarmHistory = Nothing
            m_objOperatingHistory = Nothing

            m_objMachine.Close()

            m_objMachine = Nothing

        End If
    End Sub

    Private Sub frmMain_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ' It is important to create the DataAPI.CMachine object first and call the Init method to initialize the 
        ' communication with NC, explicitly.
        ' Before exiting the application, it can call objMachine.Close to close the communication with NC.
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Try

            cboUserAlarm.DataSource = System.Enum.GetValues(GetType(Okuma.CGCMDAPI.Enumerations.UserAlarmEnum))
            cboLoaderAxisPointData.DataSource = System.Enum.GetValues(GetType(Enumerations.LoaderAxisIndexEnum))

            wkCounterSetCombo.DataSource = System.Enum.GetValues(GetType(Enumerations.WorkpieceCounterEnum))
            wkCounterCombo.DataSource = System.Enum.GetValues(GetType(Enumerations.WorkpieceCounterEnum))

            cboWheelDataUnit.DataSource = System.Enum.GetValues(GetType(Enumerations.DataUnitEnum))

            cboAxes.DataSource = System.Enum.GetValues(GetType(Enumerations.AxisIndexEnum))
            cboWheelAxes.DataSource = System.Enum.GetValues(GetType(Enumerations.WheelAxisIndexEnum))
            cboAxisDataUnit.DataSource = System.Enum.GetValues(GetType(Enumerations.DataUnitEnum))
            cboSpindleDataUnit.DataSource = System.Enum.GetValues(GetType(Enumerations.DataUnitEnum))
            cboProgramCycleSelection.DataSource = System.Enum.GetValues(GetType(Enumerations.ProgramCycleEnum))
            cboProgramDataUnit.DataSource = System.Enum.GetValues(GetType(Enumerations.DataUnitEnum))
            cboProgramDataUnit.DataSource = System.Enum.GetValues(GetType(Enumerations.DataUnitEnum))
            cboWorkpieceDataUnit.DataSource = System.Enum.GetValues(GetType(Enumerations.DataUnitEnum))
            cboDiamondToolDataUnit.DataSource = System.Enum.GetValues(GetType(Enumerations.DataUnitEnum))

            cboToolOffsetAxis.DataSource = System.Enum.GetValues(GetType(Enumerations.AxisIndexEnum))
            cboDiamondNoseRCompAxis.DataSource = System.Enum.GetValues(GetType(Enumerations.AxisIndexEnum))

            cboZeroOffsetAxis.DataSource = System.Enum.GetValues(GetType(Enumerations.AxisIndexEnum))
            cboZeroShiftAxis.DataSource = System.Enum.GetValues(GetType(Enumerations.AxisIndexEnum))

            cboWorkOffsetLocatorNegativeSideEndFace.DataSource = System.Enum.GetValues(GetType(Enumerations.AxisIndex2Enum))
            cboWorkOffsetLocatorPositiveSideEndFace.DataSource = System.Enum.GetValues(GetType(Enumerations.AxisIndex2Enum))

            cboWorkOffsetCompMeasure.DataSource = System.Enum.GetValues(GetType(Enumerations.AxisIndexEnum))
            cboWorkOffsetMasterWork.DataSource = System.Enum.GetValues(GetType(Enumerations.AxisIndexEnum))

            cboPLCBit.DataSource = System.Enum.GetValues(GetType(Enumerations.IOTypeEnum))
            cboPLCWord.DataSource = System.Enum.GetValues(GetType(Enumerations.IOTypeEnum))
            cboPLCLongWord.DataSource = System.Enum.GetValues(GetType(Enumerations.IOTypeEnum))
            cboIOVariableTypes.DataSource = System.Enum.GetValues(GetType(Enumerations.IOTypeEnum))

            cboHMSet.DataSource = System.Enum.GetValues(GetType(Enumerations.HourMeterEnum))
            cboHMCount.DataSource = System.Enum.GetValues(GetType(Enumerations.HourMeterEnum))

            cboMachiningReportType.DataSource = System.Enum.GetValues(GetType(Enumerations.ReportPeriodEnum))
            cboLoggingLevel.DataSource = System.Enum.GetValues(GetType(LoggingLevelEnum))

            m_objMachine = New DataAPI.CMachine()


            m_objMachine.Init()

            m_objAxis = New CAxis
            m_objSpindle = New CSpindle
            m_objProgram = New CProgram
            m_objWheel = New CWheel
            m_objTools = New CTools
            m_objWorkpiece = New CWorkpiece
            m_objSpec = New CSpec
            m_objIO = New CIO
            m_objVariables = New CVariables
            m_objOptionalParameter = New COptionalParameter
            m_objUserMgr = New CUserManagement

            m_objCmdProgram = New Okuma.CGCMDAPI.CommandAPI.CProgram


            m_objMachiningReport = New Okuma.CGDATAPI.DataAPI.MacMan.CMachiningReport
            m_objOperationHistory = New Okuma.CGDATAPI.DataAPI.MacMan.COperationHistory
            m_objOperatingReport = New Okuma.CGDATAPI.DataAPI.MacMan.COperatingReport
            m_objAlarmHistory = New Okuma.CGDATAPI.DataAPI.MacMan.CAlarmHistory
            m_objOperatingHistory = New Okuma.CGDATAPI.DataAPI.MacMan.COperatingHistory

            m_objIOAddress = New CIOAddress

            ' Add sample application version to form caption 
            Dim objVersion As System.Version
            Dim strVersion As String

            objVersion = [Assembly].GetExecutingAssembly.GetName().Version

            strVersion = String.Format("{0}.{1}.{2}.{3}", objVersion.Major.ToString, objVersion.Minor.ToString, objVersion.Build.ToString, objVersion.Revision.ToString)
            Me.Text = String.Format("{0} - {1}", "THINC Grinder Sample Application", strVersion)

            cboAllLoggignLevel.DataSource = System.Enum.GetValues(GetType(Enumerations.LoggingLevelEnum))

            Exit Sub

        Catch ex As Exception
            Dim objForm As frmMessage
            Dim strLabelMessage As String
            Dim strTextMessage As String


            Dim strVersion As String
            Dim objVersion As System.Version

            objVersion = [Assembly].GetExecutingAssembly.GetName().Version

            strVersion = String.Format("{0}.{1}.{2}.{3}", objVersion.Major.ToString, objVersion.Minor.ToString, objVersion.Build.ToString, objVersion.Revision.ToString)


            strLabelMessage = String.Format("{0}{1}", "Please contact OKUMA Software department to resolve problem.", ControlChars.CrLf + ControlChars.CrLf)
            strLabelMessage = strLabelMessage + String.Format("Please send the entire error message to api@okuma.com for futher investigate.")

            strTextMessage = String.Format("THINC Grinder Sample Application version {0}.{1}{2}", strVersion, ControlChars.CrLf + ControlChars.CrLf, ex.Message)
            objForm = New frmMessage(strLabelMessage, strTextMessage, MessageBoxIcon.Stop)
            objForm.ShowDialog()

        End Try
    End Sub

#End Region

#Region "Common routines"
    Private Function ArrayToString(ByRef arInt() As Int32) As String
        Dim str As System.String = ""

        Dim intCount As Integer
        Dim intIndex As Integer

        intCount = UBound(arInt)

        For intIndex = 0 To intCount
            str = str + CStr(arInt(intIndex)) + "-"
        Next

        Return str

    End Function
    Private Sub DisplayError(ByVal strSource As String, ByVal errMsg As String)
        Me.ErrorLog.Text = Now() & " - " & strSource & ": " & errMsg & vbCrLf & Me.ErrorLog.Text

    End Sub

    Private Sub clearLogButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearMessage.Click
        Me.ErrorLog.Text = ""
    End Sub
#End Region

#Region "Machine"

    Private Sub machineUpdateButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles machineUpdateButton.Click
        UpdateMachineData()
    End Sub

    Private Sub UpdateMachineData()
        Dim strValues As New StringBuilder
        Try
            strValues.Append(String.Format("Current alarm message = {0}" & vbCrLf, m_objMachine.GetCurrentAlarmMessage()))
            strValues.Append(String.Format("Dry Run State = {0}" & vbCrLf, m_objMachine.GetDryRunState()))
            strValues.Append(String.Format("Execution mode = {0}" & vbCrLf, m_objMachine.GetExecutionMode()))
            strValues.Append(String.Format("Machine Lock state = {0}" & vbCrLf, m_objMachine.GetMachineLockState()))
            strValues.Append(String.Format("NC Status.Alarm: = {0}" & vbCrLf, m_objMachine.GetNCStatus(NCStatusEnum.Alarm)))
            strValues.Append(String.Format("NC Status.Limit: = {0}" & vbCrLf, m_objMachine.GetNCStatus(NCStatusEnum.Limit)))
            strValues.Append(String.Format("NC Status.ProgramStop: = {0}" & vbCrLf, m_objMachine.GetNCStatus(NCStatusEnum.ProgramStop)))
            strValues.Append(String.Format("NC Status.Run: = {0}" & vbCrLf, m_objMachine.GetNCStatus(NCStatusEnum.Run)))
            strValues.Append(String.Format("NC Status.SlideHold: = {0}" & vbCrLf, m_objMachine.GetNCStatus(NCStatusEnum.SlideHold)))
            strValues.Append(String.Format("NC Status.STM: = {0}" & vbCrLf, m_objMachine.GetNCStatus(NCStatusEnum.STM)))
            strValues.Append(String.Format("NC Status.TurretSelection: = {0}" & vbCrLf, m_objMachine.GetNCStatus(NCStatusEnum.TurretSelection)))
            strValues.Append(String.Format("Operation Mode = {0}" & vbCrLf, m_objMachine.GetOperationMode()))
            strValues.Append(String.Format("Single block state = {0}" & vbCrLf, m_objMachine.GetSingleBlockState()))
            strValues.Append(String.Format("NC Reset state = {0}" & vbCrLf, m_objMachine.GetNCReset()))
            strValues.Append(String.Format("NC Panel mode = {0}" & vbCrLf, m_objMachine.GetPanelMode()))


            txtMachine.Text = strValues.ToString
        Catch ex As Exception
            DisplayError("machineUpdateButton_Click", ex.Message)
        End Try

    End Sub
#End Region

#Region "Machine - Hour Meter"
#Region "Hour Meter Count"

    Private Sub btnHMCount_Get_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHMCount_Get.Click
        Try
            txtHMCount.Text = m_objMachine.GetHourMeterCount(cboHMCount.SelectedValue)
        Catch ex As Exception
            DisplayError("CMachine", ex.Message)
        End Try
    End Sub

    Private Sub btnHMCount_Set_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHMCount_Set.Click
        Try
            Dim intValue As Int32 = CInt(txtHMCountValue.Text)
            m_objMachine.SetHourMeterCount(cboHMCount.SelectedValue, intValue)
        Catch ex As Exception
            DisplayError("CMachine", ex.Message)
        End Try
    End Sub

    Private Sub btnHMCount_Add_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHMCount_Add.Click
        Try
            Dim intValue As Int32 = CInt(txtHMCountValue.Text)
            m_objMachine.AddHourMeterCount(cboHMCount.SelectedValue, intValue)
        Catch ex As Exception
            DisplayError("CMachine", ex.Message)
        End Try
    End Sub

#End Region

#Region "Hour Meter Set"
    Private Sub btnHMSet_Get_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHMSet_Get.Click
        Try
            Me.txtHMSet.Text = m_objMachine.GetHourMeterSet(cboHMSet.SelectedValue)
        Catch ex As Exception
            DisplayError("CMachine", ex.Message)
        End Try
    End Sub

    Private Sub btnHMSet_Set_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHMSet_Set.Click
        Try
            Dim intValue As Int32 = CInt(txtHMSetValue.Text)
            m_objMachine.SetHourMeterSet(cboHMSet.SelectedValue, intValue)
        Catch ex As Exception
            DisplayError("CMachine", ex.Message)
        End Try
    End Sub

    Private Sub btnHMSet_Add_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHMSet_Add.Click
        Try
            Dim intValue As Int32 = CInt(txtHMSetValue.Text)
            m_objMachine.AddHourMeterSet(cboHMSet.SelectedValue, intValue)
        Catch ex As Exception
            DisplayError("CMachine", ex.Message)
        End Try
    End Sub
#End Region

#End Region
#Region "User Alarm"

    Private Sub btnClearUserAlarmD_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearUserAlarmD.Click
        Dim objmac As Okuma.CGCMDAPI.CommandAPI.CMachine

        Try
            objmac = New Okuma.CGCMDAPI.CommandAPI.CMachine
            objmac.ClearUserAlarmD()
        Catch ex As Exception
            DisplayError("Cmachine", ex.Message)
        End Try
    End Sub

    Private Sub btnSetUserAlarm_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSetUserAlarm.Click
        Dim objmac As Okuma.CGCMDAPI.CommandAPI.CMachine

        Try
            objmac = New Okuma.CGCMDAPI.CommandAPI.CMachine
            objmac.SetUserAlarm(cboUserAlarm.SelectedValue, txtUserAlarmMessage.Text.Trim())

        Catch ex As Exception
            DisplayError("Cmachine", ex.Message)
        End Try
    End Sub

#End Region


#Region "Axis"

    Private Sub btnAxisUpdate_Click(sender As System.Object, e As System.EventArgs) Handles btnAxisUpdate.Click
        Try

            UpdateAxis()
        Catch ex As Exception
            DisplayError("btnAxisUpdate_Click", ex.ToString)
        End Try
    End Sub

    Private Sub UpdateAxis()

        Dim enAxisIndex As AxisIndexEnum
        Dim enWheelAxisIndex As WheelAxisIndexEnum

        Dim enDataUnit As DataUnitEnum


        enAxisIndex = cboAxes.SelectedValue()
        enWheelAxisIndex = cboWheelAxes.SelectedValue()
        enDataUnit = cboAxisDataUnit.SelectedValue()

        m_objAxis.SetDataUnit(enDataUnit)


        txtActualPositionMachineCoordinate.Text = m_objAxis.GetActualPositionMachineCoord(enAxisIndex)
        txtActualPositionProgramCoordinate.Text = m_objAxis.GetActualPositionProgramCoord(enAxisIndex)
        txtAxisFeedrate.Text = m_objAxis.GetActualFeedrate(enAxisIndex)
        txtPathFeedrate.Text = m_objAxis.GetActualFeedrate()
        txtAxisLoad.Text = m_objAxis.GetAxisLoad(enAxisIndex)
        txtFeedrateType.Text = System.Enum.GetName(GetType(FeedrateTypeEnum), m_objAxis.GetFeedrateType())

        txtFeedrateOverride.Text = m_objAxis.GetFeedrateOverride()
        txtActualPositionWheelCoordinate.Text = m_objAxis.GetActualPositionWheelCoord(enWheelAxisIndex)


        txtCommandFeedrate.Text = m_objAxis.GetCommandFeedrate()
    End Sub

#End Region

#Region "Spindle"

    Private Sub btnSpindleUpdate_Click(sender As System.Object, e As System.EventArgs) Handles btnSpindleUpdate.Click
        Try
            UpdateSpindles()
        Catch ex As Exception
            DisplayError("btnSpindleUpdate_Click", ex.ToString)
        End Try
    End Sub

    Private Sub UpdateSpindles()

        Dim enDataUnit As DataUnitEnum


        enDataUnit = cboSpindleDataUnit.SelectedValue()

        m_objSpindle.SetDataUnit(enDataUnit)

        txtSpindleLoad.Text = m_objSpindle.GetSpindleLoad()
        txtSpindlerRateOverride.Text = m_objSpindle.GetSpindlerateOverride()
        txtSpindlSurfaceSpeed.Text = m_objSpindle.GetSpindleSurfaceSpeed()
        txtSpindleActualSpeedRate.Text = m_objSpindle.GetActualSpindlerate()
        txtCommandSpindlerate.Text = m_objSpindle.GetCommandSpindlerate()
    End Sub
    Private Sub btnSpindleSpeedSetupAdd_Click(sender As System.Object, e As System.EventArgs) Handles btntxtCommandSpindlerateAdd.Click
        Try
            m_objSpindle.AddCommandSpindlerate(CInt(txtCommandSpindlerateValue.Text))
            txtCommandSpindlerate.Text = m_objSpindle.GetCommandSpindlerate()
        Catch ex As Exception
            DisplayError("btnSpindleSpeedSetupAdd_Click", ex.ToString)
        End Try
    End Sub
    Private Sub btnSpindleSpeedSetupSet_Click(sender As System.Object, e As System.EventArgs) Handles btntxtCommandSpindlerateSet.Click
        Try
            m_objSpindle.SetCommandSpindlerate(CInt(txtCommandSpindlerateValue.Text))
            txtCommandSpindlerate.Text = m_objSpindle.GetCommandSpindlerate()
        Catch ex As Exception
            DisplayError("btnSpindleSpeedSetupSet_Click", ex.ToString)
        End Try
    End Sub

#End Region

#Region "Program"

    Private Sub btnLoadPartProgram_Click(sender As System.Object, e As System.EventArgs) Handles btnLoadPartProgram.Click
        LoadPartProgramThreadProc
    End Sub

    Private Sub LoadPartProgramThreadProc()

        Try
            Dim strMainProgramFileName As String = ""
            Dim strSubProgramFileName As String = ""
            Dim strSystemSubProgramName As String = ""
            Dim strProgramName As String = ""


            strMainProgramFileName = txtLoadPartProgramFileNameValue.Text.Trim()
            strSubProgramFileName = txtLoadSubPartProgramFileNameValue.Text.Trim()
            strSystemSubProgramName = txtLoadPartSystemSubProgramNameValue.Text.Trim()
            strProgramName = txtLoadPartProgramNameValue.Text.Trim()

            m_objCmdProgram.SelectMainProgram(strMainProgramFileName, strSubProgramFileName, strSystemSubProgramName, strProgramName)
        Catch ex As Exception
            DisplayError("btnLoadPartProgram_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnLoadSchedulePartProgram_Click(sender As System.Object, e As System.EventArgs) Handles btnLoadSchedulePartProgram.Click
        Try
            m_objCmdProgram.SelectScheduleProgram(txtLoadSchedulePartProgramValue.Text.Trim)
        Catch ae As ApplicationException
            DisplayError("btnLoadSchedulePartProgram_Click", ae.Message)
        Catch ne As NotSupportedException
            DisplayError("btnLoadSchedulePartProgram_Click", ne.Message)
        Catch ex As Exception
            DisplayError("btnLoadSchedulePartProgram_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnLoadIndexPartProgram_Click(sender As System.Object, e As System.EventArgs) Handles btnLoadIndexPartProgram.Click
        Try
            m_objCmdProgram.SelectIndexProgram(txtLoadIndexPartProgramValue.Text.Trim)
        Catch ae As ApplicationException
            DisplayError("btnLoadIndexPartProgram_Click", ae.Message)
        Catch ne As NotSupportedException
            DisplayError("btnLoadIndexPartProgram_Click", ne.Message)
        Catch ex As Exception
            DisplayError("btnLoadIndexPartProgram_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnProgramUpdate_Click(sender As System.Object, e As System.EventArgs) Handles btnProgramUpdate.Click
        Try
            UpdatePrograms()
        Catch ex As Exception
            DisplayError("btnProgramUpdate_Click", ex.ToString)
        End Try
    End Sub

    Private Sub UpdatePrograms()

        Dim enDataUnit As DataUnitEnum
        Dim enProgramCycle As ProgramCycleEnum
        Dim strValues As String

        Try


            enDataUnit = cboSpindleDataUnit.SelectedValue()
            enProgramCycle = cboProgramCycleSelection.SelectedValue()


            txtProgramBlockNumber.Text = m_objProgram.GetCurrentBlockNumber()
            txtActiveIndexProgram.Text = m_objProgram.GetActiveIndexProgram()
            txtActiveProgramFileName.Text = m_objProgram.GetActiveProgramFileName()
            txtActiveProgramName.Text = m_objProgram.GetActiveProgramName()
            txtActiveScheduleProgramFileName.Text = m_objProgram.GetActiveScheduleProgramFileName()

            txtProgramRunningState.Text = System.Enum.GetName(GetType(ProgramRunningStateEnum), m_objProgram.GetProgramRunningState())
            txtProgramCurrentCycleSelection.Text = m_objProgram.GetCurrentCycleSelection().ToString
            txtProgramCycleSelectionProgramFileName.Text = m_objProgram.GetCycleSelectProgramFileName(enProgramCycle)
            txtProgramCycleSelectionProgramName.Text = m_objProgram.GetCycleSelectProgramName(enProgramCycle)
            txtProgramExecuteSequenceNumber.Text = m_objProgram.GetExecutedSequenceNumber()
            txtActiveScheduleProgramFileName.Text = m_objProgram.GetActiveScheduleProgramFileName()

            strValues = "Execute Block: " & m_objProgram.GetExecuteBlock & vbCrLf _
                & "MCode Line 1: " & m_objProgram.GetMCodes(MCodesEnum.MCodes_Line1) & vbCrLf _
                & "MCode Line 2: " & m_objProgram.GetMCodes(MCodesEnum.MCodes_Line2) & vbCrLf _
                & "MCode Line 3: " & m_objProgram.GetMCodes(MCodesEnum.MCodes_Line3) & vbCrLf _
                & "Cycle Complete: " & m_objProgram.CycleComplete() & vbCrLf

            lstProgramOutput.Items.Clear()

            For Each strValue As String In Split(strValues, vbCrLf)
                lstProgramOutput.Items.Add(strValue)
            Next

        Catch ex As Exception
            DisplayError("CProgram", ex.Message)
        End Try
    End Sub
#End Region

#Region "Wheel"

    Private Sub btnWheel_Click(sender As System.Object, e As System.EventArgs) Handles btnWheel.Click
        Try
            UpdateWheelData()

            GetWheelData()
        Catch ex As Exception
            DisplayError("btnWheel_Click", ex.ToString)
        End Try
    End Sub

    Private Sub UpdateWheelData()

        Dim intWheelDataNo As Integer

        Dim enDataUnit As DataUnitEnum

        enDataUnit = cboWheelDataUnit.SelectedValue()

        m_objWheel.SetDataUnit(enDataUnit)

        intWheelDataNo = CInt(txtWheelDataNo.Text)


        txtWheelActualSpindleRate.Text = m_objWheel.GetActualWheelrate
        txtWheelCommandSpindleRate.Text = m_objWheel.GetCommandWheelrate
        txtWheelDataNumber.Text = m_objWheel.GetCurrentWheelDataNumber
        txtWheelDiamondToolOffsetNumber.Text = m_objWheel.GetCurrentDiamondToolOffsetNumber
        txtWheelEffectLoad.Text = m_objWheel.GetWheelLoad(WheelLoadEnum.EffectLoad)
        txtWheelGAPLoad.Text = m_objWheel.GetWheelLoad(WheelLoadEnum.GAPLoad)
        txtWheelMeasureLoad.Text = m_objWheel.GetWheelLoad(WheelLoadEnum.MeasureLoad)
        txtWheelOLLoad.Text = m_objWheel.GetWheelLoad(WheelLoadEnum.OLLoad)
        txtWheelPPCLoad.Text = m_objWheel.GetWheelLoad(WheelLoadEnum.PPCLoad)
        txtWheelReferencePosition.Text = m_objWheel.GetWheelReferencePosition
        txtWheelSpindleRateOverride.Text = m_objWheel.GetWheelrateOverride()
        txtWheelSpindleSurfaceSpeed.Text = m_objWheel.GetWheelSurfaceSpeed()
        txtWheelSurfaceSpeedSetup.Text = m_objWheel.GetWheelSurfaceSpeedSetup()
        txtWheelCommandSpindleRate.Text = m_objWheel.GetCommandWheelrate()

        txtMaxWheelData.Text = m_objWheel.GetMaxWheelData()

        txtWheelType.Text = m_objWheel.GetWheelType(intWheelDataNo)
        txtWheelShape.Text = m_objWheel.GetWheelShape(intWheelDataNo)

        txtWheelMaxWheels.Text = m_objWheel.GetMaxWheels()

    End Sub

    Private Sub GetWheelData()
        Dim strValues As StringBuilder = New StringBuilder
        Dim objWheelData As CWheelData

        objWheelData = m_objWheel.GetWheelData(CInt(txtWheelDataNo.Text))

        lstWheelData.Items.Clear()

        lstWheelData.Items.Add(String.Format("InsideDiameter: {0}", objWheelData.InsideDiameter.ToString()))
        lstWheelData.Items.Add(String.Format("LengthPeriphery: {0}", objWheelData.LengthPeriphery.ToString()))
        lstWheelData.Items.Add(String.Format("LengthSideFace: {0}", objWheelData.LengthSideFace.ToString()))
        lstWheelData.Items.Add(String.Format("MaximumOperatingSpeed: {0}", objWheelData.MaximumOperatingSpeed.ToString()))
        lstWheelData.Items.Add(String.Format("OutSideDiameter: {0}", objWheelData.OutSideDiameter.ToString()))
        lstWheelData.Items.Add(String.Format("OutSideDiameterChange: {0}", objWheelData.OutSideDiameterChange.ToString()))
        lstWheelData.Items.Add(String.Format("OutSideDiameterForcast: {0}", objWheelData.OutSideDiameterForeCast.ToString()))
        lstWheelData.Items.Add(String.Format("OutSideDiameterIntial: {0}", objWheelData.OutSideDiameterInitial.ToString()))
        lstWheelData.Items.Add(String.Format("RadiusLeft: {0}", objWheelData.RadiusLeft.ToString()))
        lstWheelData.Items.Add(String.Format("RadiusRight: {0}", objWheelData.RadiusRight.ToString()))
        lstWheelData.Items.Add(String.Format("SlopeAngleLeft: {0}", objWheelData.SlopeAngleLeft.ToString()))
        lstWheelData.Items.Add(String.Format("SlopeAngleRight: {0}", objWheelData.SlopeAngleRight.ToString()))
        lstWheelData.Items.Add(String.Format("TaperAngleLeft: {0}", objWheelData.TaperAngleLeft.ToString()))
        lstWheelData.Items.Add(String.Format("TaperAnglePeriphery: {0}", objWheelData.TaperAnglePeriphery.ToString()))
        lstWheelData.Items.Add(String.Format("TaperAngleRight: {0}", objWheelData.TaperAngleRight.ToString()))
        lstWheelData.Items.Add(String.Format("TaperLengthLeft: {0}", objWheelData.TaperLengthLeft.ToString()))
        lstWheelData.Items.Add(String.Format("TaperLengthRight: {0}", objWheelData.TaperLengthRight.ToString()))
        lstWheelData.Items.Add(String.Format("TiltAngle: {0}", objWheelData.TiltAngle.ToString()))
        lstWheelData.Items.Add(String.Format("WidthLeftChange: {0}", objWheelData.WidthLeftChange.ToString()))
        lstWheelData.Items.Add(String.Format("WidthLeftForeCast: {0}", objWheelData.WidthLeftForeCast.ToString()))
        lstWheelData.Items.Add(String.Format("WidthLeftInitial: {0}", objWheelData.WidthLeftInitial.ToString()))
        lstWheelData.Items.Add(String.Format("WidthPeriphery: {0}", objWheelData.WidthPeriphery.ToString()))
        lstWheelData.Items.Add(String.Format("WidthPeripheryInitial: {0}", objWheelData.WidthPeripheryInitial.ToString()))
        lstWheelData.Items.Add(String.Format("WidthRight: {0}", objWheelData.WidthRight.ToString()))
        lstWheelData.Items.Add(String.Format("WidthRightChange: {0}", objWheelData.WidthRightChange.ToString()))
        lstWheelData.Items.Add(String.Format("WidthRightForeCast: {0}", objWheelData.WidthRightForeCast.ToString()))
        lstWheelData.Items.Add(String.Format("WidthRightInitial: {0}", objWheelData.WidthRightInitial.ToString()))
        lstWheelData.Items.Add(String.Format("WidthSideFace: {0}", objWheelData.WidthSideFace.ToString()))
        lstWheelData.Items.Add(String.Format("WidthSideFaceInitial: {0}", objWheelData.WidthSideFaceInitial.ToString()))
        lstWheelData.Items.Add(String.Format("X Offset: {0}", objWheelData.XOffset.ToString()))
        lstWheelData.Items.Add(String.Format("Z Offset: {0}", objWheelData.ZOffset.ToString()))




    End Sub

    Private Sub btnReferencePositionSet_Click(sender As System.Object, e As System.EventArgs) Handles btnReferencePositionSet.Click
        Try
            m_objWheel.SetWheelReferencePosition(CInt(txtWheelReferencePositionValue.Text))
            txtWheelReferencePosition.Text = m_objWheel.GetWheelReferencePosition()
        Catch ex As Exception
            DisplayError("btnReferencePositionSet_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnWheelDiamondToolOffsetNumberSet_Click(sender As System.Object, e As System.EventArgs) Handles btnWheelDiamondToolOffsetNumberSet.Click
        Try
            Dim enDataUnit As DataUnitEnum

            enDataUnit = cboWheelDataUnit.SelectedValue()

            m_objWheel.SetDataUnit(enDataUnit)
            m_objWheel.SetCurrentDiamondToolOffsetNumber(CInt(txtWheelDiamondToolOffsetNumberValue.Text))
            txtWheelDiamondToolOffsetNumber.Text = m_objWheel.GetCurrentDiamondToolOffsetNumber()
        Catch ex As Exception
            DisplayError("btnWheelDiamondToolOffsetNumberSet_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnWheelDataNumberAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnWheelDataNumberAdd.Click
        Try
            m_objWheel.AddCurrentWheelDataNumber(CInt(txtWheelDataNumberValue.Text))
            txtWheelDataNumber.Text = m_objWheel.GetCurrentWheelDataNumber()
        Catch ex As Exception
            DisplayError("btnWheelDataNumberAdd_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnWheelDataNumberSet_Click(sender As System.Object, e As System.EventArgs) Handles btnWheelDataNumberSet.Click
        Try
            m_objWheel.SetCurrentWheelDataNumber(CInt(txtWheelDataNumberValue.Text))
            txtWheelDataNumber.Text = m_objWheel.GetCurrentWheelDataNumber()

        Catch ex As Exception
            DisplayError("btnWheelDataNumberSet_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnReferencePositionAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnReferencePositionAdd.Click
        Try
            m_objWheel.AddWheelReferencePosition(CInt(txtWheelReferencePositionValue.Text))
            txtWheelReferencePosition.Text = m_objWheel.GetWheelReferencePosition()
        Catch ex As Exception
            DisplayError("btnReferencePositionAdd_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnWheelDiamondToolOffsetNumberAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnWheelDiamondToolOffsetNumberAdd.Click
        Try
            Dim enDataUnit As DataUnitEnum

            enDataUnit = cboWheelDataUnit.SelectedValue()

            m_objWheel.SetDataUnit(enDataUnit)
            m_objWheel.AddCurrentDiamondToolOffsetNumber(CInt(txtWheelDiamondToolOffsetNumberValue.Text))
            txtWheelDiamondToolOffsetNumber.Text = m_objWheel.GetCurrentDiamondToolOffsetNumber()
        Catch ex As Exception
            DisplayError("btnWheelDiamondToolOffsetNumberAdd_Click", ex.ToString)
        End Try
    End Sub



    Private Sub btnCommandWheelSurfaceSpeedSet_Click(sender As System.Object, e As System.EventArgs)
        Try
            m_objWheel.SetWheelSurfaceSpeedSetup(CInt(txtWheelSurfaceSpeedSetupValue.Text))
            txtWheelSurfaceSpeedSetup.Text = m_objWheel.GetWheelSurfaceSpeedSetup()

        Catch ex As Exception
            DisplayError("btnCommandWheelSurfaceSpeedSet_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnCommandWheelSurfaceSpeedAdd_Click(sender As System.Object, e As System.EventArgs)
        Try
            m_objWheel.AddWheelSurfaceSpeedSetup(CInt(txtWheelSurfaceSpeedSetupValue.Text))
            txtWheelSurfaceSpeedSetup.Text = m_objWheel.GetWheelSurfaceSpeedSetup()
        Catch ex As Exception
            DisplayError("btnCommandWheelSurfaceSpeedAdd_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnWheelSurfaceSpeedSetupSet_Click(sender As System.Object, e As System.EventArgs) Handles btnWheelSurfaceSpeedSetupSet.Click
        Try
            Dim enDataUnit As DataUnitEnum

            enDataUnit = cboWheelDataUnit.SelectedValue()

            m_objWheel.SetDataUnit(enDataUnit)
            m_objWheel.SetWheelSurfaceSpeedSetup(CInt(txtWheelSurfaceSpeedSetupValue.Text))
            txtWheelSurfaceSpeedSetup.Text = m_objWheel.GetWheelSurfaceSpeedSetup()
        Catch ex As Exception
            DisplayError("btnWheelSurfaceSpeedSetupSet_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnWheelSurfaceSpeedSetupAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnWheelSurfaceSpeedSetupAdd.Click
        Try
            Dim enDataUnit As DataUnitEnum

            enDataUnit = cboWheelDataUnit.SelectedValue()

            m_objWheel.SetDataUnit(enDataUnit)
            m_objWheel.AddWheelSurfaceSpeedSetup(CInt(txtWheelSurfaceSpeedSetupValue.Text))
            txtWheelSurfaceSpeedSetup.Text = m_objWheel.GetWheelSurfaceSpeedSetup()
        Catch ex As Exception
            DisplayError("btnWheelSurfaceSpeedSetupAdd_Click", ex.ToString)
        End Try
    End Sub

#End Region

#Region "Tool Offset"

    Private Sub btnDiamondTool_Click(sender As System.Object, e As System.EventArgs) Handles btnDiamondTool.Click
        Try

            UpdateTools()
        Catch ex As Exception
            DisplayError("btnDiamondTool_Click", ex.ToString)
        End Try
    End Sub


    Private Sub UpdateTools()

        Dim enDataUnit As DataUnitEnum
        Dim intIndex As Integer
        Dim enToolOffsetAxisIndex As AxisIndexEnum
        Dim enNoseRCompAxisIndex As AxisIndexEnum


        enDataUnit = cboDiamondToolDataUnit.SelectedValue()

        m_objTools.SetDataUnit(enDataUnit)

        intIndex = CInt(txtDiamondToolIndex.Text)

        enToolOffsetAxisIndex = cboToolOffsetAxis.SelectedValue
        enNoseRCompAxisIndex = cboDiamondNoseRCompAxis.SelectedValue


        txtToolOffset.Text = m_objTools.GetToolOffset(intIndex, enToolOffsetAxisIndex)
        txtDiamondNoseRComp.Text = m_objTools.GetNoseRCompensation(intIndex, enNoseRCompAxisIndex)

        txtCurrentTool.Text = m_objTools.GetCurrentToolNumber()

    End Sub

    Private Sub btnToolOffsetSet_Click(sender As System.Object, e As System.EventArgs) Handles btnToolOffsetSet.Click
        Try

            Dim enDataUnit As DataUnitEnum
            Dim intIndex As Integer
            Dim enToolOffsetAxisIndex As AxisIndexEnum


            enDataUnit = cboDiamondToolDataUnit.SelectedValue()
            enToolOffsetAxisIndex = cboToolOffsetAxis.SelectedValue

            m_objTools.SetDataUnit(enDataUnit)

            intIndex = CInt(txtDiamondToolIndex.Text)
            m_objTools.SetToolOffset(intIndex, enToolOffsetAxisIndex, CDbl(txtToolOffsetValue.Text))
            txtToolOffset.Text = m_objTools.GetToolOffset(intIndex, enToolOffsetAxisIndex)
        Catch ex As Exception
            DisplayError("btnToolOffsetSet_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnToolOffsetAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnToolOffsetAdd.Click
        Try

            Dim enDataUnit As DataUnitEnum
            Dim intIndex As Integer
            Dim enToolOffsetAxisIndex As AxisIndexEnum


            enDataUnit = cboDiamondToolDataUnit.SelectedValue()
            enToolOffsetAxisIndex = cboToolOffsetAxis.SelectedValue

            m_objTools.SetDataUnit(enDataUnit)

            intIndex = CInt(txtDiamondToolIndex.Text)
            m_objTools.AddToolOffset(intIndex, enToolOffsetAxisIndex, CDbl(txtToolOffsetValue.Text))
            txtToolOffset.Text = m_objTools.GetToolOffset(intIndex, enToolOffsetAxisIndex)
        Catch ex As Exception
            DisplayError("btnToolOffsetSet_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnDiamondToolNoseRCompSet_Click(sender As System.Object, e As System.EventArgs) Handles btnDiamondToolNoseRCompSet.Click
        Try

            Dim enDataUnit As DataUnitEnum
            Dim intIndex As Integer
            Dim enNoseRCompAxisIndex As AxisIndexEnum


            enDataUnit = cboDiamondToolDataUnit.SelectedValue()

            enNoseRCompAxisIndex = cboDiamondNoseRCompAxis.SelectedValue

            m_objTools.SetDataUnit(enDataUnit)

            intIndex = CInt(txtDiamondToolIndex.Text)
            m_objTools.SetNoseRCompensation(intIndex, enNoseRCompAxisIndex, CDbl(txtDiamondNoseRCompValue.Text))
            txtDiamondNoseRComp.Text = m_objTools.GetNoseRCompensation(intIndex, enNoseRCompAxisIndex)
        Catch ex As Exception
            DisplayError("btnDiamondToolNoseRCompSet_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnDiamondToolNoseRCompAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnDiamondToolNoseRCompAdd.Click
        Try

            Dim enDataUnit As DataUnitEnum
            Dim intIndex As Integer
            Dim enNoseRCompAxisIndex As AxisIndexEnum


            enDataUnit = cboDiamondToolDataUnit.SelectedValue()

            enNoseRCompAxisIndex = cboDiamondNoseRCompAxis.SelectedValue

            m_objTools.SetDataUnit(enDataUnit)

            intIndex = CInt(txtDiamondToolIndex.Text)
            m_objTools.AddNoseRCompensation(intIndex, enNoseRCompAxisIndex, CDbl(txtDiamondNoseRCompValue.Text))
            txtDiamondNoseRComp.Text = m_objTools.GetNoseRCompensation(intIndex, enNoseRCompAxisIndex)
        Catch ex As Exception
            DisplayError("btnDiamondToolNoseRCompAdd_Click", ex.ToString)
        End Try
    End Sub

#End Region

#Region "Workpiece"
    Private Sub btnUpdateWorkpiece_Click(sender As System.Object, e As System.EventArgs) Handles btnUpdateWorkpiece.Click
        Try

            UpdateWorkpiece()
        Catch ex As Exception
            DisplayError("btnUpdateWorkpiece_Click", ex.ToString)
        End Try
    End Sub

    Private Sub UpdateWorkpiece()

        Dim enDataUnit As DataUnitEnum
        Dim enZeroOffsetAxisIndex As AxisIndexEnum
        Dim enZeroShiftAxisIndex As AxisIndexEnum
        Dim enAxisIndex As AxisIndexEnum


        enDataUnit = cboWorkpieceDataUnit.SelectedValue()

        m_objWorkpiece.SetDataUnit(enDataUnit)

        enZeroOffsetAxisIndex = cboZeroOffsetAxis.SelectedValue
        enZeroShiftAxisIndex = cboZeroShiftAxis.SelectedValue


        txtZeroOffset.Text = m_objWorkpiece.GetZeroOffset(enZeroOffsetAxisIndex)
        txtZeroShift.Text = m_objWorkpiece.GetZeroShift(enZeroShiftAxisIndex)

        enAxisIndex = cboWorkOffsetMasterWork.SelectedValue
        txtMasterWorkOffset.Text = m_objWorkpiece.GetWorkpieceMasterWork(enAxisIndex)


        enAxisIndex = cboWorkOffsetCompMeasure.SelectedValue
        txtCompMeasure.Text = m_objWorkpiece.GetWorkpieceCompensationMeasure(enAxisIndex)

        enAxisIndex = cboWorkOffsetLocatorNegativeSideEndFace.SelectedValue
        txtWorkLocatorNegativeSideEndFace.Text = m_objWorkpiece.GetWorkLocatorOffsetNegativeSideEndFace(enAxisIndex)

        enAxisIndex = cboWorkOffsetLocatorPositiveSideEndFace.SelectedValue
        txtWorkLocatorPositiveSideEndFace.Text = m_objWorkpiece.GetWorkLocatorOffsetPositiveSideEndFace(enAxisIndex)

    End Sub


    Private Sub btnZeroShiftAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnZeroShiftAdd.Click
        Try

            Dim enDataUnit As DataUnitEnum
            Dim dblValue As Double
            Dim enAxisIndex As AxisIndexEnum


            enDataUnit = cboWorkpieceDataUnit.SelectedValue()

            enAxisIndex = cboZeroShiftAxis.SelectedValue

            m_objWorkpiece.SetDataUnit(enDataUnit)
            dblValue = CDbl(txtZeroShiftValue.Text)

            m_objWorkpiece.AddZeroShift(enAxisIndex, dblValue)
            txtZeroShift.Text = m_objWorkpiece.GetZeroShift(enAxisIndex)
        Catch ex As Exception
            DisplayError("btnZeroShiftAdd_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnZeroShiftSet_Click(sender As System.Object, e As System.EventArgs) Handles btnZeroShiftSet.Click
        Try

            Dim enDataUnit As DataUnitEnum
            Dim dblValue As Double
            Dim enAxisIndex As AxisIndexEnum
            enDataUnit = cboWorkpieceDataUnit.SelectedValue()
            enAxisIndex = cboZeroShiftAxis.SelectedValue

            m_objWorkpiece.SetDataUnit(enDataUnit)
            dblValue = CDbl(txtZeroShiftValue.Text)

            m_objWorkpiece.SetZeroShift(enAxisIndex, dblValue)
            txtZeroShift.Text = m_objWorkpiece.GetZeroShift(enAxisIndex)

        Catch ex As Exception
            DisplayError("btnZeroShiftAdd_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnZeroOffsetAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnZeroOffsetAdd.Click
        Try

            Dim enDataUnit As DataUnitEnum
            Dim dblValue As Double
            Dim enAxisIndex As AxisIndexEnum

            enDataUnit = cboWorkpieceDataUnit.SelectedValue()
            enAxisIndex = cboZeroOffsetAxis.SelectedValue

            m_objWorkpiece.SetDataUnit(enDataUnit)
            dblValue = CDbl(txtZeroOffsetValue.Text)

            m_objWorkpiece.AddZeroOffset(enAxisIndex, dblValue)
            txtZeroOffset.Text = m_objWorkpiece.GetZeroOffset(enAxisIndex)
        Catch ex As Exception
            DisplayError("btnZeroOffsetAdd_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnZeroOffsetSetSet_Click(sender As System.Object, e As System.EventArgs) Handles btnZeroOffsetSetSet.Click
        Try

            Dim enDataUnit As DataUnitEnum
            Dim dblValue As Double
            Dim enAxisIndex As AxisIndexEnum

            enDataUnit = cboWorkpieceDataUnit.SelectedValue()
            enAxisIndex = cboZeroOffsetAxis.SelectedValue

            m_objWorkpiece.SetDataUnit(enDataUnit)
            dblValue = CDbl(txtZeroOffsetValue.Text)

            m_objWorkpiece.SetZeroOffset(enAxisIndex, dblValue)
            txtZeroOffset.Text = m_objWorkpiece.GetZeroOffset(enAxisIndex)
        Catch ex As Exception
            DisplayError("btnZeroOffsetSetSet_Click", ex.ToString)
        End Try
    End Sub

#Region "Work Locator - Negative Side End Face"
    Private Sub btnWorkLocatorNegativeSideEndFaceSet_Click(sender As System.Object, e As System.EventArgs) Handles btnWorkLocatorNegativeSideEndFaceSet.Click
        Try

            Dim enDataUnit As DataUnitEnum
            Dim dblValue As Double
            Dim enAxisIndex As AxisIndexEnum


            enDataUnit = cboWorkpieceDataUnit.SelectedValue()

            enAxisIndex = cboWorkOffsetLocatorNegativeSideEndFace.SelectedValue

            m_objWorkpiece.SetDataUnit(enDataUnit)
            dblValue = CDbl(txtWorkLocatorNegativeSideEndFaceValue.Text)

            m_objWorkpiece.SetWorkLocatorOffsetNegativeSideEndFace(enAxisIndex, dblValue)
            txtWorkLocatorNegativeSideEndFace.Text = m_objWorkpiece.GetWorkLocatorOffsetNegativeSideEndFace(enAxisIndex)
        Catch ex As Exception
            DisplayError("btnWorkLocatorNegativeSideEndFaceSet_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnWorkLocatorNegativeSideEndFaceAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnWorkLocatorNegativeSideEndFaceAdd.Click
        Try

            Dim enDataUnit As DataUnitEnum
            Dim dblValue As Double
            Dim enAxisIndex As AxisIndexEnum


            enDataUnit = cboWorkpieceDataUnit.SelectedValue()

            enAxisIndex = cboWorkOffsetLocatorNegativeSideEndFace.SelectedValue

            m_objWorkpiece.SetDataUnit(enDataUnit)
            dblValue = CDbl(txtWorkLocatorNegativeSideEndFaceValue.Text)

            m_objWorkpiece.AddWorkLocatorOffsetNegativeSideEndFace(enAxisIndex, dblValue)
            txtWorkLocatorNegativeSideEndFace.Text = m_objWorkpiece.GetWorkLocatorOffsetNegativeSideEndFace(enAxisIndex)
        Catch ex As Exception
            DisplayError("btnWorkLocatorNegativeSideEndFaceAdd_Click", ex.ToString)
        End Try
    End Sub

#End Region

#Region "Work Locator - Positive Side End Face"
    Private Sub btnWorkLocatorPositiveSideEndFaceAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnWorkLocatorPositiveSideEndFaceAdd.Click
        Try

            Dim enDataUnit As DataUnitEnum
            Dim dblValue As Double
            Dim enAxisIndex As AxisIndexEnum


            enDataUnit = cboWorkpieceDataUnit.SelectedValue()

            enAxisIndex = cboWorkOffsetLocatorPositiveSideEndFace.SelectedValue

            m_objWorkpiece.SetDataUnit(enDataUnit)
            dblValue = CDbl(txtWorkLocatorPositiveSideEndFaceValue.Text)

            m_objWorkpiece.AddWorkLocatorOffsetPositiveSideEndFace(enAxisIndex, dblValue)
            txtWorkLocatorPositiveSideEndFace.Text = m_objWorkpiece.GetWorkLocatorOffsetPositiveSideEndFace(enAxisIndex)
        Catch ex As Exception
            DisplayError("btnWorkLocatorPositiveSideEndFaceAdd_Click", ex.ToString)
        End Try
    End Sub
    Private Sub btnWorkLocatorPositiveSideEndFaceSet_Click(sender As System.Object, e As System.EventArgs) Handles btnWorkLocatorPositiveSideEndFaceSet.Click
        Try

            Dim enDataUnit As DataUnitEnum
            Dim dblValue As Double
            Dim enAxisIndex As AxisIndexEnum


            enDataUnit = cboWorkpieceDataUnit.SelectedValue()

            enAxisIndex = cboWorkOffsetLocatorPositiveSideEndFace.SelectedValue

            m_objWorkpiece.SetDataUnit(enDataUnit)
            dblValue = CDbl(txtWorkLocatorPositiveSideEndFaceValue.Text)

            m_objWorkpiece.SetWorkLocatorOffsetPositiveSideEndFace(enAxisIndex, dblValue)
            txtWorkLocatorPositiveSideEndFace.Text = m_objWorkpiece.GetWorkLocatorOffsetPositiveSideEndFace(enAxisIndex)
        Catch ex As Exception
            DisplayError("btnWorkLocatorPositiveSideEndFaceSet_Click", ex.ToString)
        End Try
    End Sub
#End Region

#Region "Workpiece Counter Set"
    Private Sub btnWPCounterSet_Get_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnWPCounterSet_Get.Click
        Try
            Dim cnt As Int32
            cnt = m_objWorkpiece.GetWorkpieceCounterSet(wkCounterSetCombo.SelectedValue)
            Me.txtWPCounterSet.Text = cnt
        Catch ex As Exception
            DisplayError("btnWPCounterSet_Get_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnWPCounterSet_Set_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnWPCounterSet_Set.Click
        Try
            m_objWorkpiece.SetWorkpieceCounterSet(Me.wkCounterSetCombo.SelectedValue, CInt(Me.txtWPCounterSetValue.Text))
            Dim cnt As Int32
            cnt = m_objWorkpiece.GetWorkpieceCounterSet(wkCounterSetCombo.SelectedValue)
            Me.txtWPCounterSet.Text = cnt
        Catch ex As Exception
            DisplayError("btnWPCounterSet_Set_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnWPCounterSet_Add_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnWPCounterSet_Add.Click
        Try
            m_objWorkpiece.AddWorkpieceCounterSet(Me.wkCounterSetCombo.SelectedValue, CInt(Me.txtWPCounterSetValue.Text))
            Dim cnt As Int32
            cnt = m_objWorkpiece.GetWorkpieceCounterSet(wkCounterSetCombo.SelectedValue)
            Me.txtWPCounterSet.Text = cnt
        Catch ex As Exception
            DisplayError("btnWPCounterSet_Add_Click", ex.ToString)
        End Try
    End Sub
#End Region
#Region "Workpiece Counter Count"
    Private Sub cmd_addWorkpiece_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd_addWorkpiece.Click
        Try
            m_objWorkpiece.AddWorkpieceCounter(Me.wkCounterCombo.SelectedValue, CInt(Me.wkUpdateCounter.Text))
            Dim cnt As Int32
            cnt = m_objWorkpiece.GetWorkpieceCounter(wkCounterCombo.SelectedValue)
            Me.wkCounterValue.Text = cnt
        Catch ex As Exception
            DisplayError("cmd_addWorkpiece_Click", ex.ToString)
        End Try
    End Sub

    Private Sub wkGetCounterValue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles wkGetCounterValue.Click
        Try
            Dim cnt As Int32
            cnt = m_objWorkpiece.GetWorkpieceCounter(wkCounterCombo.SelectedValue)
            Me.wkCounterValue.Text = cnt
        Catch ex As Exception
            DisplayError("wkGetCounterValue_Click", ex.ToString)
        End Try
    End Sub


    Private Sub wkSetCounterValue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles wkSetCounterValue.Click
        Try
            m_objWorkpiece.SetWorkpieceCounter(Me.wkCounterCombo.SelectedValue, CInt(Me.wkUpdateCounter.Text))
            Dim cnt As Int32
            cnt = m_objWorkpiece.GetWorkpieceCounter(wkCounterCombo.SelectedValue)
            Me.wkCounterValue.Text = cnt
        Catch ex As Exception
            DisplayError("wkSetCounterValue_Click", ex.ToString)
        End Try
    End Sub
#End Region


    Private Sub btnMasterWorkOffsetSet_Click(sender As System.Object, e As System.EventArgs) Handles btnMasterWorkOffsetSet.Click
        Try
            Dim enDataUnit As DataUnitEnum
            Dim dblValue As Double
            Dim enAxisIndex As AxisIndexEnum

            enDataUnit = cboWorkpieceDataUnit.SelectedValue()
            enAxisIndex = cboWorkOffsetMasterWork.SelectedValue

            m_objWorkpiece.SetDataUnit(enDataUnit)
            dblValue = CDbl(txtMasterWorkOffsetValue.Text)

            m_objWorkpiece.SetWorkpieceMasterWork(enAxisIndex, dblValue)
            txtMasterWorkOffset.Text = m_objWorkpiece.GetWorkpieceMasterWork(enAxisIndex)
        Catch ex As Exception
            DisplayError("btnMasterWorkOffsetSet_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnMasterWorkOffsetAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnMasterWorkOffsetAdd.Click
        Try

            Dim enDataUnit As DataUnitEnum
            Dim dblValue As Double
            Dim enAxisIndex As AxisIndexEnum
            enDataUnit = cboWorkpieceDataUnit.SelectedValue()
            enAxisIndex = cboWorkOffsetMasterWork.SelectedValue

            m_objWorkpiece.SetDataUnit(enDataUnit)
            dblValue = CDbl(txtMasterWorkOffsetValue.Text)

            m_objWorkpiece.AddWorkpieceMasterWork(enAxisIndex, dblValue)
            txtMasterWorkOffset.Text = m_objWorkpiece.GetWorkpieceMasterWork(enAxisIndex)
        Catch ex As Exception
            DisplayError("btnMasterWorkOffsetSet_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnCompMeasureSet_Click(sender As System.Object, e As System.EventArgs) Handles btnCompMeasureSet.Click
        Try

            Dim enDataUnit As DataUnitEnum
            Dim dblValue As Double
            Dim enAxisIndex As AxisIndexEnum


            enDataUnit = cboWorkpieceDataUnit.SelectedValue()

            enAxisIndex = cboWorkOffsetCompMeasure.SelectedValue

            m_objWorkpiece.SetDataUnit(enDataUnit)
            dblValue = CDbl(txtCompMeasureValue.Text)

            m_objWorkpiece.SetWorkpieceCompensationMeasure(enAxisIndex, dblValue)
            txtCompMeasure.Text = m_objWorkpiece.GetWorkpieceCompensationMeasure(enAxisIndex)
        Catch ex As Exception
            DisplayError("btnCompMeasureAdd_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnCompMeasureAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnCompMeasureAdd.Click
        Try

            Dim enDataUnit As DataUnitEnum
            Dim dblValue As Double
            Dim enAxisIndex As AxisIndexEnum


            enDataUnit = cboWorkpieceDataUnit.SelectedValue()

            enAxisIndex = cboWorkOffsetCompMeasure.SelectedValue

            m_objWorkpiece.SetDataUnit(enDataUnit)
            dblValue = CDbl(txtCompMeasureValue.Text)

            m_objWorkpiece.AddWorkpieceCompensationMeasure(enAxisIndex, dblValue)
            txtCompMeasure.Text = m_objWorkpiece.GetWorkpieceCompensationMeasure(enAxisIndex)
        Catch ex As Exception
            DisplayError("btnCompMeasureAdd_Click", ex.ToString)
        End Try
    End Sub

#End Region

#Region "PLC I/O"
    Private Sub btnGetBit_Click(sender As System.Object, e As System.EventArgs) Handles btnGetBit.Click
        Try
            Dim enValue As IOTypeEnum
            enValue = cboPLCBit.SelectedValue

            txtPLCBitData.Text = m_objIO.GetBitIO(enValue, CInt(txtPLCBitAddress.Text), CInt(txtPLCBit.Text)).ToString
        Catch ex As Exception
            DisplayError("btnGetBit_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnGetWord_Click(sender As System.Object, e As System.EventArgs) Handles btnGetWord.Click
        Try
            Dim enValue As IOTypeEnum
            enValue = cboPLCWord.SelectedValue

            txtPLCWordData.Text = m_objIO.GetWordIO(enValue, CInt(txtPLCWordAddress.Text)).ToString
        Catch ex As Exception
            DisplayError("btnGetWord_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnGetLongWord_Click(sender As System.Object, e As System.EventArgs) Handles btnGetLongWord.Click
        Try
            Dim enValue As IOTypeEnum
            enValue = cboPLCLongWord.SelectedValue

            txtPLCLongWordData.Text = m_objIO.GetLongWordIO(enValue, CInt(txtPLCLongWordAddress.Text)).ToString
        Catch ex As Exception
            DisplayError("btnGetLongWord_Click", ex.ToString)
        End Try
    End Sub

    Private Sub cmdIOGetBitByLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdIOGetBitByLabel.Click
        Try
            Dim objIOAddress As CIOAddress = New CIOAddress

            objIOAddress.Address = CInt(txtPLCBitAddress.Text)
            objIOAddress.Bit = CInt(txtPLCBit.Text)
            objIOAddress.IOType = cboPLCBit.SelectedValue
            objIOAddress.Size = IOAddressSizeEnum.Bit

            txtIOBitLabel.Text = m_objIO.GetLabel(objIOAddress)
        Catch ex As Exception
            DisplayError("I/O Variables", ex.Message)
        End Try
    End Sub

    Private Sub cmdIOGetWordByLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdIOGetWordByLabel.Click
        Try
            Dim objIOAddress As CIOAddress = New CIOAddress

            objIOAddress.Address = CInt(txtPLCWordAddress.Text)
            objIOAddress.Bit = 0
            objIOAddress.IOType = cboPLCWord.SelectedValue
            objIOAddress.Size = IOAddressSizeEnum.Word

            txtIOWordLabel.Text = m_objIO.GetLabel(objIOAddress)
        Catch ex As Exception
            DisplayError("I/O Variables", ex.Message)
        End Try
    End Sub

    Private Sub cmdIOGetLongWordByLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdIOGetLongWordByLabel.Click
        Try
            Dim objIOAddress As CIOAddress = New CIOAddress

            objIOAddress.Address = CInt(txtPLCLongWordAddress.Text)
            objIOAddress.Bit = 0
            objIOAddress.IOType = cboPLCLongWord.SelectedValue
            objIOAddress.Size = IOAddressSizeEnum.DWord

            txtIOLongWordLabel.Text = m_objIO.GetLabel(objIOAddress)
        Catch ex As Exception
            DisplayError("I/O Variables", ex.Message)
        End Try
    End Sub

    Private Sub btnGetIOLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetIOLabel.Click
        Try
            Dim objIOAddress As CIOAddress

            txtPLCBitAddress.Text = ""
            txtPLCBit.Text = ""
            txtPLCBitData.Text = ""
            txtPLCWordData.Text = ""
            txtPLCWordAddress.Text = ""
            txtPLCLongWordAddress.Text = ""
            txtPLCLongWordData.Text = ""

            objIOAddress = m_objIO.GetIO(txtIOLabel.Text)

            Dim t As Threading.Thread

            t = New Threading.Thread(AddressOf GetIOThread)
            t.SetApartmentState(Threading.ApartmentState.STA)

            t.Start()

            cboIOVariableTypes.SelectedIndex = objIOAddress.IOType

            Select Case objIOAddress.Size
                Case IOAddressSizeEnum.Bit
                    txtPLCBitAddress.Text = objIOAddress.Address
                    txtPLCBit.Text = objIOAddress.Bit
                    txtPLCBitData.Text = objIOAddress.Value

                Case IOAddressSizeEnum.Word
                    txtPLCWordAddress.Text = objIOAddress.Address
                    txtPLCWordData.Text = objIOAddress.Value

                Case IOAddressSizeEnum.DWord
                    txtPLCLongWordAddress.Text = objIOAddress.Address
                    txtPLCLongWordData.Text = objIOAddress.Value

                Case Else
                    DisplayError("I/O Variables", "Not found")
            End Select
        Catch ex As Exception
            DisplayError("I/O Variables", ex.Message)
        End Try
    End Sub

    Private Sub GetIOThread()
        Try
            m_objIOAddress = m_objIO.GetIO("ipNTS_B")

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

#End Region

#Region "CVariables"

    Private Sub btnCommonVariableUpdate_Click(sender As System.Object, e As System.EventArgs) Handles btnCommonVariableUpdate.Click
        Try
            txtCommonVariableData.Text = m_objVariables.GetCommonVariableValue(CInt(Me.txtCommonVariable.Text))
            txtCommonVariablesCount.Text = m_objVariables.GetCommonVariableCount
        Catch ex As Exception
            DisplayError("btnCommonVariableUpdate_Click", ex.ToString)
        End Try
    End Sub
    Private Sub btnAddCommonVariables_Click(sender As System.Object, e As System.EventArgs) Handles btnAddCommonVariables.Click
        Try

            m_objVariables.AddCommonVariableValue(CInt(Me.txtCommonVariable.Text), CDbl(txtCommonVariableValue.Text))
            txtCommonVariableData.Text = m_objVariables.GetCommonVariableValue(CInt(Me.txtCommonVariable.Text))
        Catch ex As Exception
            DisplayError("btnAddCommonVariables_Click", ex.ToString)
        End Try
    End Sub
    Private Sub btnSetCommonVariables_Click(sender As System.Object, e As System.EventArgs) Handles btnSetCommonVariables.Click
        Try
            m_objVariables.SetCommonVariableValue(CInt(Me.txtCommonVariable.Text), CDbl(txtCommonVariableValue.Text))
            txtCommonVariableData.Text = m_objVariables.GetCommonVariableValue(CInt(Me.txtCommonVariable.Text))
        Catch ex As Exception
            DisplayError("btnSetCommonVariables_Click", ex.ToString)
        End Try
    End Sub
    Private Sub btnGetCommonVariable_Click(sender As System.Object, e As System.EventArgs) Handles btnGetCommonVariable.Click
        Try
            txtCommonVariableData.Text = m_objVariables.GetCommonVariableValue(CInt(Me.txtCommonVariable.Text))
        Catch ex As Exception
            DisplayError("btnGetCommonVariable_Click", ex.ToString)
        End Try
    End Sub
    Private Sub btnGetCommonVariables_Click(sender As System.Object, e As System.EventArgs) Handles btnGetCommonVariables.Click
        Try
            Dim strValues As New StringBuilder
            Dim dblValue As Double
            Dim arValues() As Double
            Dim intStartingIndex As Integer
            Dim intEndingIndex As Integer
            Dim intIndex As Integer

            intStartingIndex = CInt(txtCommonVariableStartingIndex.Text)
            intEndingIndex = CInt(txtCommonVariableEndingIndex.Text)

            arValues = m_objVariables.GetCommonVariableValues(intStartingIndex, intEndingIndex)

            intIndex = intStartingIndex

            For Each dblValue In arValues
                strValues.Append(String.Format("Index {0}: {1}" + vbCrLf, intIndex.ToString, dblValue))
                intIndex = intIndex + 1
            Next

            txtCommonVarialbesData.Text = strValues.ToString
        Catch ex As Exception
            DisplayError("btnGetCommonVariables_Click", ex.ToString)
        End Try
    End Sub

#End Region

#Region "MacMan - Machining Reports"
    Private Sub btnMacManMachiningReportUpdate_Click(sender As System.Object, e As System.EventArgs) Handles btnMacManMachiningReportUpdate.Click

        Try

            Dim objMachining As MacMan.CMachining
            Dim enReport As ReportPeriodEnum
            Dim intReportIndex As Int16

            enReport = cboMachiningReportType.SelectedItem
            intReportIndex = CInt(txtMacManReportIndex.Text)
            objMachining = m_objMachiningReport.GetMachiningReport(intReportIndex, enReport)

            txtMachiningReportCount.Text = m_objMachiningReport.GetCount(enReport)
            txtMachiningReportMaxCount.Text = m_objMachiningReport.GetMaxCount(enReport)

            txtMachiningReportStartTime.Text = objMachining.StartTime
            Me.txtMachiningReportStartDate.Text = objMachining.StartDate

            txtMachiningReportCuttingTime.Text = objMachining.CuttingTime
            txtMachiningReportOperatingTime.Text = objMachining.OperatingTime
            Me.txtMachiningReportRunningTime.Text = objMachining.RunningTime
            txtMachiningReportProgramName.Text = objMachining.MainProgramFileName
            txtMachiningReportMainProgram.Text = objMachining.MainProgramName
            txtMachiningReportNoOfWork.Text = objMachining.NumberOfWork
        Catch ex As Exception
            DisplayError("btnMacManMachiningReportUpdate_Click", ex.ToString)
        End Try

    End Sub

    Private Sub btnMacManMachiningReportUpdates_Click(sender As System.Object, e As System.EventArgs) Handles btnMacManMachiningReportUpdates.Click
        Dim enReport As ReportPeriodEnum
        Dim intReportStartIndex As Int16
        Dim intReportEndIndex As Int16
        Dim arMachining As ArrayList
        Try
            enReport = cboMachiningReportType.SelectedItem
            intReportStartIndex = CInt(txtMachiningReportFromIndex.Text)
            intReportEndIndex = CInt(txtMachiningReportToIndex.Text)
            arMachining = m_objMachiningReport.GetMachiningReports(intReportStartIndex, intReportEndIndex, enReport)
            grdMachiningReports.DataSource = arMachining
            grdMachiningReports.Refresh()
        Catch ex As Exception
            DisplayError("btnMacManMachiningReportUpdates_Click", ex.ToString)
        End Try
    End Sub
#End Region

#Region "MacMan - Operation History"
    Private Sub btnOperationHistoryUpdate_Click(sender As System.Object, e As System.EventArgs) Handles btnOperationHistoryUpdate.Click
        Try
            Dim opIndex As Int16
            Dim objOperationHisotry As DataApi.MacMan.COperation

            opIndex = CInt(txtOperationHistoryIndex.Text)

            objOperationHisotry = m_objOperationHistory.GetOperationHistory(opIndex)

            txtOperationHistoryData.Text = objOperationHisotry.Data
            txtOperationHistoryDate.Text = objOperationHisotry.Date
            txtOperationHistoryTime.Text = objOperationHisotry.Time
            txtOperationHistoryCount.Text = m_objOperationHistory.GetCount
            txtOperationHistoryMaxCount.Text = m_objOperationHistory.GetMaxCount
        Catch ex As Exception
            DisplayError("btnOperationHistoryUpdate_Click", ex.ToString)
        End Try

    End Sub
    Private Sub btnOperationHistoryUpdates_Click(sender As System.Object, e As System.EventArgs) Handles btnOperationHistoryUpdates.Click
        Dim objOperation As DataApi.MacMan.COperation
        Dim arOperations As ArrayList

        Try
            lstOperationHistory.Items.Clear()
            arOperations = m_objOperationHistory.GetOperationHistory(CInt(txtOperationHistoryFromIndex.Text), CInt(txtOperationHistoryToIndex.Text))
            For Each objOperation In arOperations
                lstOperationHistory.Items.Add(objOperation.Date & vbTab & objOperation.Time & vbTab & objOperation.Data)
            Next
        Catch ex As Exception
            DisplayError("btnOperationHistoryUpdates_Click", ex.ToString)
        End Try
    End Sub
#End Region

#Region "MacMan - Operating Report"
    Private Sub btnOperatingReportUpdate_Click(sender As System.Object, e As System.EventArgs) Handles btnOperatingReportUpdate.Click
        Try

            Me.txtDateOfOperatingReport.Text = m_objOperatingReport.GetTodayOperatingReportDate()
            Me.txtMaxNoOfOpReport.Text = m_objOperatingReport.GetMaxCount()

            Me.txtOperatingTime.Text = m_objOperatingReport.GetTodayOperatingReport(OperatingReportDataEnum.OperatingTime)
            Me.txtRunningTime.Text = m_objOperatingReport.GetTodayOperatingReport(OperatingReportDataEnum.RunningTime)
            Me.txtCuttingTime.Text = m_objOperatingReport.GetTodayOperatingReport(OperatingReportDataEnum.CuttingTime)
            Me.txtNonOPeratingTime.Text = m_objOperatingReport.GetTodayOperatingReport(OperatingReportDataEnum.NonOperatingTime)
            Me.txtInProSetupTime.Text = m_objOperatingReport.GetTodayOperatingReport(OperatingReportDataEnum.InProcessSetupTime)
            Me.txtNoOperatorTime.Text = m_objOperatingReport.GetTodayOperatingReport(OperatingReportDataEnum.NoOperatorTime)
            Me.txtPartWaitingTime.Text = m_objOperatingReport.GetTodayOperatingReport(OperatingReportDataEnum.PartWaitingTime)
            Me.txtmaintenanceTime.Text = m_objOperatingReport.GetTodayOperatingReport(OperatingReportDataEnum.MaintenanceTime)
            Me.txtOtherTime.Text = m_objOperatingReport.GetTodayOperatingReport(OperatingReportDataEnum.OtherTime)
            Me.txtSpindleRunTime.Text = m_objOperatingReport.GetTodayOperatingReport(OperatingReportDataEnum.SpindleRunTime)
            Me.txtExternalInputTime.Text = m_objOperatingReport.GetTodayOperatingReport(OperatingReportDataEnum.ExternalInputTime)
            Me.txtAlarmOnTime.Text = m_objOperatingReport.GetTodayOperatingReport(OperatingReportDataEnum.AlarmOnTime)

            Me.txtPrevDateOfOperatingRept.Text = m_objOperatingReport.GetPreviousOperatingReportDate()

            Me.txtPrevAlarmOnTime.Text = m_objOperatingReport.GetPreviousOperatingReport(OperatingReportDataEnum.AlarmOnTime)
            Me.txtPrevCuttingTime.Text = m_objOperatingReport.GetPreviousOperatingReport(OperatingReportDataEnum.CuttingTime)
            Me.txtPrevInProSetupTime.Text = m_objOperatingReport.GetPreviousOperatingReport(OperatingReportDataEnum.InProcessSetupTime)
            Me.txtPrevMaintenanceTime.Text = m_objOperatingReport.GetPreviousOperatingReport(OperatingReportDataEnum.MaintenanceTime)
            Me.txtPrevNonOperatingTime.Text = m_objOperatingReport.GetPreviousOperatingReport(OperatingReportDataEnum.NonOperatingTime)
            Me.txtPrevNoOperatorTime.Text = m_objOperatingReport.GetPreviousOperatingReport(OperatingReportDataEnum.NoOperatorTime)
            Me.txtPrevOperatingTime.Text = m_objOperatingReport.GetPreviousOperatingReport(OperatingReportDataEnum.OperatingTime)
            Me.txtPrevOtherTime.Text = m_objOperatingReport.GetPreviousOperatingReport(OperatingReportDataEnum.OtherTime)
            Me.txtPrevPartwaitingTime.Text = m_objOperatingReport.GetPreviousOperatingReport(OperatingReportDataEnum.PartWaitingTime)
            Me.txtPrevRunningTime.Text = m_objOperatingReport.GetPreviousOperatingReport(OperatingReportDataEnum.RunningTime)
            Me.txtPrevSpindleRunTime.Text = m_objOperatingReport.GetPreviousOperatingReport(OperatingReportDataEnum.SpindleRunTime)
            Me.txtPrevExternalInputTime.Text = m_objOperatingReport.GetPreviousOperatingReport(OperatingReportDataEnum.ExternalInputTime)


            Me.txtPeriodDateOfOperatingReport.Text = m_objOperatingReport.GetPeriodOperatingReportDate()

            Me.txtPeriodAlarmOnTime.Text = m_objOperatingReport.GetPeriodOperatingReport(OperatingReportDataEnum.AlarmOnTime)
            Me.txtPeriodCuttingTime.Text = m_objOperatingReport.GetPeriodOperatingReport(OperatingReportDataEnum.CuttingTime)
            Me.txtPeriodExternalInputTime.Text = m_objOperatingReport.GetPeriodOperatingReport(OperatingReportDataEnum.ExternalInputTime)
            Me.txtPeriodInproSetupTime.Text = m_objOperatingReport.GetPeriodOperatingReport(OperatingReportDataEnum.InProcessSetupTime)
            Me.txtPeriodMaintenanceTime.Text = m_objOperatingReport.GetPeriodOperatingReport(OperatingReportDataEnum.MaintenanceTime)
            Me.txtPeriodNonOperatingTime.Text = m_objOperatingReport.GetPeriodOperatingReport(OperatingReportDataEnum.NonOperatingTime)
            Me.txtPeriodNoOperatorTime.Text = m_objOperatingReport.GetPeriodOperatingReport(OperatingReportDataEnum.NoOperatorTime)
            Me.txtPeriodOperatingTime.Text = m_objOperatingReport.GetPeriodOperatingReport(OperatingReportDataEnum.OperatingTime)
            Me.txtPeriodOtherTime.Text = m_objOperatingReport.GetPeriodOperatingReport(OperatingReportDataEnum.OtherTime)
            Me.txtPeriodPartWaitingTime.Text = m_objOperatingReport.GetPeriodOperatingReport(OperatingReportDataEnum.PartWaitingTime)
            Me.txtPeriodRunningTime.Text = m_objOperatingReport.GetPeriodOperatingReport(OperatingReportDataEnum.RunningTime)
            Me.txtPeriodSpindleRunTime.Text = m_objOperatingReport.GetPeriodOperatingReport(OperatingReportDataEnum.SpindleRunTime)
        Catch ex As Exception
            DisplayError("btnOperatingReportUpdate_Click", ex.ToString)
        End Try
    End Sub
#End Region

#Region "MacMan - Operating History"
    Private Sub btnAlarmHistoryUpdate_Click(sender As System.Object, e As System.EventArgs) Handles btnAlarmHistoryUpdate.Click
        Try
            Dim intAlarmIndex As Integer
            Dim objAlarm As DataApi.MacMan.CAlarm
            intAlarmIndex = CInt(Me.txtAlarmIndex.Text)
            objAlarm = m_objAlarmHistory.GetAlarm(intAlarmIndex)

            Me.txtAlarmCode.Text = objAlarm.Code
            Me.txtAlarmDate.Text = objAlarm.Date
            Me.txtAlarmMessage.Text = objAlarm.Message
            Me.txtAlarmNumber.Text = objAlarm.Number
            Me.txtAlarmTime.Text = objAlarm.Time
            Me.txtAlarmObject.Text = objAlarm.Object

            Me.txtMaxAlarmCount.Text = m_objAlarmHistory.GetMaxCount
            Me.txtAlarmCount.Text = m_objAlarmHistory.GetCount
        Catch ex As Exception
            DisplayError("btnAlarmHistoryUpdate_Click", ex.ToString)
        End Try
    End Sub
    Private Sub btnAlarmHistoryUpdates_Click(sender As System.Object, e As System.EventArgs) Handles btnAlarmHistoryUpdates.Click
        Dim objAlarm As DataApi.MacMan.CAlarm
        Dim arAlarms As ArrayList
        Dim intIndex As Integer

        Try
            arAlarms = m_objAlarmHistory.GetAlarms(CInt(Me.txtAlarmHistoryFromIndex.Text), CInt(Me.txtAlarmHistoryEndIndex.Text))
            intIndex = CInt(Me.txtAlarmHistoryFromIndex.Text)
            For Each objAlarm In arAlarms
                lstAlarms.Items.Add(intIndex.ToString & vbTab & objAlarm.Date & vbTab & objAlarm.Time & vbTab & objAlarm.Number & vbTab & objAlarm.Object & vbTab & objAlarm.Code & vbTab & objAlarm.Message)
                intIndex = intIndex + 1
            Next
        Catch ex As Exception
            DisplayError("btnAlarmHistoryUpdates_Click", ex.ToString)
        End Try
    End Sub
#End Region

#Region "Spec"
    Private Sub btnGetNCSpec2_Click(sender As System.Object, e As System.EventArgs) Handles btnGetNCSpec2.Click
        Try
            txtNCSpec2.Text = m_objSpec.GetBSpecCode(CInt(txtNCSpec2AddressValue.Text), CInt(txtNCSpec2BitValue.Text)).ToString
        Catch ex As Exception
            DisplayError("btnGetNCSpec2_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnGetNCSpec_Click(sender As System.Object, e As System.EventArgs) Handles btnGetNCSpec.Click
        Try
            txtNCSpec.Text = m_objSpec.GetSpecCode(CInt(txtNCSpecAddressValue.Text), CInt(txtNCSpecBitValue.Text)).ToString
        Catch ex As Exception
            DisplayError("btnGetNCSpec_Click", ex.ToString)
        End Try
    End Sub

    Private Sub btnSpecUpdate_Click(sender As System.Object, e As System.EventArgs) Handles btnSpecUpdate.Click
        Try
            txtMachineName.Text = m_objSpec.GetMachineName()
            txtMachineSerial.Text = m_objSpec.GetMachineSerialNumber()

            txtOSPControlType.Text = System.Enum.GetName(GetType(ControlTypeEnum), m_objSpec.GetControlType())
        Catch ex As Exception
            DisplayError("btnSpecUpdate_Click", ex.ToString)
        End Try
    End Sub

#End Region

#Region "MacMan - Operating History"
    Private Sub btnMacManOperatingHistoryUpdate_Click(sender As System.Object, e As System.EventArgs) Handles btnMacManOperatingHistoryUpdate.Click
        Try

            txtMacManOperatingHistoryAlarmOnTime.Text = ArrayToString(m_objOperatingHistory.GetTodayOperatingHistory(CInt(Me.txtMacManOperatingHistoryFromIndex.Text), CInt(Me.txtMacManOperatingHistoryToIndex.Text), OperatingReportDataEnum.AlarmOnTime))
            txtMacManOperatingHistoryCuttingTime.Text = ArrayToString(m_objOperatingHistory.GetTodayOperatingHistory(CInt(Me.txtMacManOperatingHistoryFromIndex.Text), CInt(Me.txtMacManOperatingHistoryToIndex.Text), OperatingReportDataEnum.CuttingTime))
            txtMacManOperatingHistoryExternalInputTime.Text = ArrayToString(m_objOperatingHistory.GetTodayOperatingHistory(CInt(Me.txtMacManOperatingHistoryFromIndex.Text), CInt(Me.txtMacManOperatingHistoryToIndex.Text), OperatingReportDataEnum.ExternalInputTime))
            txtMacManOperatingHistoryInProSetupTime.Text = ArrayToString(m_objOperatingHistory.GetTodayOperatingHistory(CInt(Me.txtMacManOperatingHistoryFromIndex.Text), CInt(Me.txtMacManOperatingHistoryToIndex.Text), OperatingReportDataEnum.InProcessSetupTime))
            txtMacManOperatingHistoryMaintenanceTime.Text = ArrayToString(m_objOperatingHistory.GetTodayOperatingHistory(CInt(Me.txtMacManOperatingHistoryFromIndex.Text), CInt(Me.txtMacManOperatingHistoryToIndex.Text), OperatingReportDataEnum.MaintenanceTime))
            txtMacManOperatingHistoryNonOperatingReport.Text = ArrayToString(m_objOperatingHistory.GetTodayOperatingHistory(CInt(Me.txtMacManOperatingHistoryFromIndex.Text), CInt(Me.txtMacManOperatingHistoryToIndex.Text), OperatingReportDataEnum.NonOperatingTime))
            txtMacManOperatingHistoryNoOperatorTime.Text = ArrayToString(m_objOperatingHistory.GetTodayOperatingHistory(CInt(Me.txtMacManOperatingHistoryFromIndex.Text), CInt(Me.txtMacManOperatingHistoryToIndex.Text), OperatingReportDataEnum.NoOperatorTime))
            txtMacManOperatingHistoryOperatingTime.Text = ArrayToString(m_objOperatingHistory.GetTodayOperatingHistory(CInt(Me.txtMacManOperatingHistoryFromIndex.Text), CInt(Me.txtMacManOperatingHistoryToIndex.Text), OperatingReportDataEnum.OperatingTime))
            txtMacManOperatingHistoryOtherTime.Text = ArrayToString(m_objOperatingHistory.GetTodayOperatingHistory(CInt(Me.txtMacManOperatingHistoryFromIndex.Text), CInt(Me.txtMacManOperatingHistoryToIndex.Text), OperatingReportDataEnum.OtherTime))
            txtMacManOperatingHistoryPartWaitingTime.Text = ArrayToString(m_objOperatingHistory.GetTodayOperatingHistory(CInt(Me.txtMacManOperatingHistoryFromIndex.Text), CInt(Me.txtMacManOperatingHistoryToIndex.Text), OperatingReportDataEnum.PartWaitingTime))
            txtMacManOperatingHistoryRunningTime.Text = ArrayToString(m_objOperatingHistory.GetTodayOperatingHistory(CInt(Me.txtMacManOperatingHistoryFromIndex.Text), CInt(Me.txtMacManOperatingHistoryToIndex.Text), OperatingReportDataEnum.RunningTime))
            txtMacManOperatingHistorySpindleRunTime.Text = ArrayToString(m_objOperatingHistory.GetTodayOperatingHistory(CInt(Me.txtMacManOperatingHistoryFromIndex.Text), CInt(Me.txtMacManOperatingHistoryToIndex.Text), OperatingReportDataEnum.SpindleRunTime))

            txtMacManOperatingHistoryPrevAlarmonTime.Text = ArrayToString(m_objOperatingHistory.GetPreviousOperatingHistory(CInt(Me.txtMacManOperatingHistoryFromIndex.Text), CInt(Me.txtMacManOperatingHistoryToIndex.Text), OperatingReportDataEnum.AlarmOnTime))
            txtMacManOperatingHistoryPrevCuttingTime.Text = ArrayToString(m_objOperatingHistory.GetPreviousOperatingHistory(CInt(Me.txtMacManOperatingHistoryFromIndex.Text), CInt(Me.txtMacManOperatingHistoryToIndex.Text), OperatingReportDataEnum.CuttingTime))
            txtMacManOperatingHistoryPrevExternalInputTime.Text = ArrayToString(m_objOperatingHistory.GetPreviousOperatingHistory(CInt(Me.txtMacManOperatingHistoryFromIndex.Text), CInt(Me.txtMacManOperatingHistoryToIndex.Text), OperatingReportDataEnum.ExternalInputTime))
            txtMacManOperatingHistoryPrevInProSetupTime.Text = ArrayToString(m_objOperatingHistory.GetPreviousOperatingHistory(CInt(Me.txtMacManOperatingHistoryFromIndex.Text), CInt(Me.txtMacManOperatingHistoryToIndex.Text), OperatingReportDataEnum.InProcessSetupTime))
            txtMacManOperatingHistoryPrevMaintenanceTime.Text = ArrayToString(m_objOperatingHistory.GetPreviousOperatingHistory(CInt(Me.txtMacManOperatingHistoryFromIndex.Text), CInt(Me.txtMacManOperatingHistoryToIndex.Text), OperatingReportDataEnum.MaintenanceTime))
            txtMacManOperatingHistoryPrevNonOperatingTime.Text = ArrayToString(m_objOperatingHistory.GetPreviousOperatingHistory(CInt(Me.txtMacManOperatingHistoryFromIndex.Text), CInt(Me.txtMacManOperatingHistoryToIndex.Text), OperatingReportDataEnum.NonOperatingTime))
            txtMacManOperatingHistoryPrevNoOperatorTime.Text = ArrayToString(m_objOperatingHistory.GetPreviousOperatingHistory(CInt(Me.txtMacManOperatingHistoryFromIndex.Text), CInt(Me.txtMacManOperatingHistoryToIndex.Text), OperatingReportDataEnum.NoOperatorTime))
            txtMacManOperatingHistoryPrevOperatingTime.Text = ArrayToString(m_objOperatingHistory.GetPreviousOperatingHistory(CInt(Me.txtMacManOperatingHistoryFromIndex.Text), CInt(Me.txtMacManOperatingHistoryToIndex.Text), OperatingReportDataEnum.OperatingTime))
            txtMacManOperatingHistoryPrevOtherTime.Text = ArrayToString(m_objOperatingHistory.GetPreviousOperatingHistory(CInt(Me.txtMacManOperatingHistoryFromIndex.Text), CInt(Me.txtMacManOperatingHistoryToIndex.Text), OperatingReportDataEnum.OtherTime))
            txtMacManOperatingHistoryPrevPartWaitingTime.Text = ArrayToString(m_objOperatingHistory.GetPreviousOperatingHistory(CInt(Me.txtMacManOperatingHistoryFromIndex.Text), CInt(Me.txtMacManOperatingHistoryToIndex.Text), OperatingReportDataEnum.PartWaitingTime))
            txtMacManOperatingHistoryPrevRunningTime.Text = ArrayToString(m_objOperatingHistory.GetPreviousOperatingHistory(CInt(Me.txtMacManOperatingHistoryFromIndex.Text), CInt(Me.txtMacManOperatingHistoryToIndex.Text), OperatingReportDataEnum.RunningTime))
            txtMacManOperatingHistoryPrevSpindleRunTime.Text = ArrayToString(m_objOperatingHistory.GetPreviousOperatingHistory(CInt(Me.txtMacManOperatingHistoryFromIndex.Text), CInt(Me.txtMacManOperatingHistoryToIndex.Text), OperatingReportDataEnum.SpindleRunTime))

            txtMacManOperatingHistoryMaxCount.Text = m_objOperatingHistory.GetMaxCount()

        Catch ex As Exception
            DisplayError("btnMacManOperatingHistoryUpdate_Click", ex.ToString)
        End Try
    End Sub
#End Region

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
    End Sub

#Region " Logging Service"
    Private Sub btnDisplayLogRecords_Click(sender As System.Object, e As System.EventArgs) Handles btnDisplayLogRecords.Click
        Dim lstRecords As List(Of CLogRecord)
        Dim objApiLog As Okuma.ApiLog2.CApiLog
        objApiLog = New Okuma.ApiLog2.CApiLog

        Dim strAppName As String
        Dim strClassName As String
        Dim strMethodName As String
        Dim strParameters As String
        Dim strMessage As String
        Dim enLoggingLevel As LoggingLevelEnum = LoggingLevelEnum.logAll

        Dim dtStartDate As Date
        Dim dtEnddate As Date

        dtStartDate = dtpStartingDate.Value
        dtEnddate = dtpEndingDate.Value
        strAppName = txtLogAppName.Text.Trim()
        strClassName = txtLogClassName.Text.Trim()
        strMethodName = txtLogFunctionName.Text.Trim()
        strParameters = txtLogIOParameters.Text.Trim()
        strMessage = txtLogMessage.Text.Trim()
        enLoggingLevel = cboLoggingLevel.SelectedItem


        lstRecords = objApiLog.GetLogs(dtStartDate, dtEnddate, strAppName, strClassName, strMethodName, strParameters, strMessage, enLoggingLevel)
        dgvLogging.DataSource = lstRecords


    End Sub

    Private Sub cboAllLoggignLevel_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cboAllLoggignLevel.SelectedIndexChanged
        Dim enLoggigngLevel As LoggingLevelEnum

        enLoggigngLevel = cboAllLoggignLevel.SelectedItem

        Select Case enLoggigngLevel
            Case LoggingLevelEnum.logAll
                SetLoggingLevelAll()
            Case LoggingLevelEnum.logGet
                SetLoggingLevelGet()
            Case LoggingLevelEnum.logSet
                SetLoggingLevelSet()
            Case Else
                SetLoggingLevelSet()
        End Select
    End Sub

    Private Sub SetLoggingLevelAll()
        m_objAxis.SetLoggingLevelToAll()
        m_objSpindle.SetLoggingLevelToAll()
        m_objProgram.SetLoggingLevelToAll()
        m_objWheel.SetLoggingLevelToAll()
        m_objTools.SetLoggingLevelToAll()
        m_objWorkpiece.SetLoggingLevelToAll()
        m_objSpec.SetLoggingLevelToAll()
        m_objIO.SetLoggingLevelToAll()
        m_objVariables.SetLoggingLevelToAll()

        m_objCmdProgram.SetLoggingLevelToAll()


        m_objOperationHistory.SetLoggingLevelToAll()
        m_objMachiningReport.SetLoggingLevelToAll()
        m_objOperatingReport.SetLoggingLevelToAll()
        m_objAlarmHistory.SetLoggingLevelToAll()
        m_objOperatingHistory.SetLoggingLevelToAll()

        m_objMachine.SetLoggingLevelToAll()
    End Sub

    Private Sub SetLoggingLevelGet()
        m_objAxis.SetLoggingLevelToGet()
        m_objSpindle.SetLoggingLevelToGet()
        m_objProgram.SetLoggingLevelToGet()
        m_objWheel.SetLoggingLevelToGet()
        m_objTools.SetLoggingLevelToGet()
        m_objWorkpiece.SetLoggingLevelToGet()
        m_objSpec.SetLoggingLevelToGet()
        m_objIO.SetLoggingLevelToGet()
        m_objVariables.SetLoggingLevelToGet()

        m_objCmdProgram.SetLoggingLevelToGet()


        m_objOperationHistory.SetLoggingLevelToGet()
        m_objMachiningReport.SetLoggingLevelToGet()
        m_objOperatingReport.SetLoggingLevelToGet()
        m_objAlarmHistory.SetLoggingLevelToGet()
        m_objOperatingHistory.SetLoggingLevelToGet()

        m_objMachine.SetLoggingLevelToGet()
    End Sub

    Private Sub SetLoggingLevelSet()
        m_objAxis.SetLoggingLevelToSet()
        m_objSpindle.SetLoggingLevelToSet()
        m_objProgram.SetLoggingLevelToSet()
        m_objWheel.SetLoggingLevelToSet()
        m_objTools.SetLoggingLevelToSet()
        m_objWorkpiece.SetLoggingLevelToSet()
        m_objSpec.SetLoggingLevelToSet()
        m_objIO.SetLoggingLevelToSet()
        m_objVariables.SetLoggingLevelToSet()

        m_objCmdProgram.SetLoggingLevelToSet()


        m_objOperationHistory.SetLoggingLevelToSet()
        m_objMachiningReport.SetLoggingLevelToSet()
        m_objOperatingReport.SetLoggingLevelToSet()
        m_objAlarmHistory.SetLoggingLevelToSet()
        m_objOperatingHistory.SetLoggingLevelToSet()

        m_objMachine.SetLoggingLevelToSet()
    End Sub
#End Region

#Region "User Management Functions"

    Private Sub btnLogOut_Click(sender As System.Object, e As System.EventArgs) Handles btnLogOut.Click
        Try
            CDataApi_Samples.LogOut()
        Catch ex As Exception
            DisplayError("User Management Functions ", ex.Message)
        End Try
    End Sub

    Private Sub btnLogIn_Click(sender As System.Object, e As System.EventArgs) Handles btnLogIn.Click
        Try
            CDataApi_Samples.LogIn(txtUserID.Text.Trim(), txtPassword.Text.Trim)
        Catch ex As Exception
            DisplayError("User Management Functions ", ex.Message)
        End Try
    End Sub

    Private Sub btnGotoHomeScreen_Click(sender As System.Object, e As System.EventArgs) Handles btnGotoHomeScreen.Click
        Try
            CDataApi_Samples.GotoHomeScreen()
        Catch ex As Exception
            DisplayError("User Management Functions ", ex.Message)
        End Try
    End Sub

#End Region

#Region "Optional Parameter"
    Private Sub cmdOptionalParameterBitGet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOptionalParameterBitGet.Click
        Try
            Me.txtOptionalParameterBit.Text = m_objOptionalParameter.GetNCOptionalParameterBit(CInt(Me.txtOptionalParameterBitIndex.Text), CInt(Me.txtOptionalParameterBitNo.Text))
        Catch ex As Exception
            DisplayError("Optional Parameter", ex.Message)
        End Try
    End Sub

    Private Sub cmdOptionalParameterWordGet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOptionalParameterWordGet.Click
        Try
            txtOptionalParameterWord.Text = m_objOptionalParameter.GetNCOptionalParameterWord(CInt(Me.txtOptionalParameterWordIndex.Text))
        Catch ex As Exception
            DisplayError("Optional Parameter", ex.Message)
        End Try
    End Sub

    Private Sub cmdOptionalParameterLongWordGet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOptionalParameterLongWordGet.Click
        Try
            txtOptionalParameterLongWord.Text = m_objOptionalParameter.GetNCOptionalParameterLongWord(CInt(Me.txtOptionalParameterLongWordIndex.Text))
        Catch ex As Exception
            DisplayError("Optional Parameter", ex.Message)
        End Try
    End Sub


    Private Sub cmdBitSet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBitSet.Click
        Try
            m_objOptionalParameter.SetNCOptionalParameterBit(CInt(Me.txtOptionalParameterBitIndex.Text), CInt(Me.txtOptionalParameterBitNo.Text), CInt(txtBitInput.Text))
        Catch ex As Exception
            DisplayError("Optional Parameter", ex.Message)
        End Try
    End Sub

    Private Sub cmdWordSet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdWordSet.Click
        Try
            m_objOptionalParameter.SetNCOptionalParameterWord(CInt(Me.txtOptionalParameterWordIndex.Text), CInt(txtWordInput.Text))
        Catch ex As Exception
            DisplayError("Optional Parameter", ex.Message)
        End Try
    End Sub

    Private Sub cmdLongWordSet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdLongWordSet.Click
        Try
            m_objOptionalParameter.SetNCOptionalParameterLongWord(CInt(Me.txtOptionalParameterLongWordIndex.Text), CInt(txtLongWordInput.Text))
        Catch ex As Exception
            DisplayError("Optional Parameter", ex.Message)
        End Try
    End Sub

    Private Sub cmdWordAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdWordAdd.Click
        Try
            m_objOptionalParameter.AddNCOptionalParameterWord(CInt(Me.txtOptionalParameterWordIndex.Text), CInt(txtWordInput.Text))
        Catch ae As ApplicationException
            DisplayError("Optional Parameter", ae.Message)
        Catch ex As Exception
            DisplayError("Optional Parameter", ex.Message)
        End Try
    End Sub

    Private Sub cmdLongWordAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdLongWordAdd.Click
        Try
            m_objOptionalParameter.AddNCOptionalParameterLongWord(CInt(Me.txtOptionalParameterLongWordIndex.Text), CInt(txtLongWordInput.Text))
        Catch ex As Exception
            DisplayError("Optional Parameter", ex.Message)
        End Try
    End Sub

    Private Sub frmMain_ImeModeChanged(sender As Object, e As EventArgs) Handles Me.ImeModeChanged

    End Sub
#End Region
End Class
